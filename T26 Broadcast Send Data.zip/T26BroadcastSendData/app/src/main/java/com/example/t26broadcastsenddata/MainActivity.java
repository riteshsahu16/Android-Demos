package com.example.t26broadcastsenddata;

import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
/**
 * Main Activity - Demonstrates sending broadcasts with data
 *
 * Shows:
 * 1. Sending broadcast with String, int, boolean data
 * 2. Sending broadcast with notification data
 * 3. Sending broadcast with complex data (Bundle, arrays)
 * 4. Dynamic receiver registration
 * 5. Custom broadcast actions
 */
public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";

    // Custom broadcast action strings
    // Best practice: Use app package name as prefix
    private static final String ACTION_USER_DATA = "com.example.ACTION_USER_DATA";
    private static final String ACTION_NOTIFICATION = "com.example.ACTION_NOTIFICATION";
    private static final String ACTION_COMPLEX_DATA = "com.example.ACTION_COMPLEX_DATA";

    // BroadcastReceiver instance
    private CustomDataReceiver customReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Log.d(TAG, "");
        Log.d(TAG, "╔════════════════════════════════════════╗");
        Log.d(TAG, "║   BROADCAST DATA DEMO                  ║");
        Log.d(TAG, "╚════════════════════════════════════════╝");
        Log.d(TAG, "");
        Log.d(TAG, "This demo shows how to:");
        Log.d(TAG, "  1. Send broadcast with data (putExtra)");
        Log.d(TAG, "  2. Receive broadcast in BroadcastReceiver");
        Log.d(TAG, "  3. Extract data from Intent");
        Log.d(TAG, "  4. Display data via Toast and logs");
        Log.d(TAG, "");

        // Register broadcast receiver dynamically
        registerCustomReceiver();

        // Send broadcasts with delays to see clear separation
        sendBroadcastsWithDelay();
    }
    /**
     * Register BroadcastReceiver dynamically
     * This is the recommended approach for app-specific broadcasts
     */
    private void registerCustomReceiver() {
        Log.d(TAG, "═══ REGISTERING BROADCAST RECEIVER ═══");
        Log.d(TAG, "");

        // Create receiver instance
        customReceiver = new CustomDataReceiver();

        // Create IntentFilter with custom actions
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(ACTION_USER_DATA);
        intentFilter.addAction(ACTION_NOTIFICATION);
        intentFilter.addAction(ACTION_COMPLEX_DATA);

        // Register receiver
        registerReceiver(customReceiver, intentFilter);

        Log.d(TAG, "✓ Receiver registered for actions:");
        Log.d(TAG, "  - " + ACTION_USER_DATA);
        Log.d(TAG, "  - " + ACTION_NOTIFICATION);
        Log.d(TAG, "  - " + ACTION_COMPLEX_DATA);
        Log.d(TAG, "");
    }

    /**
     * Send multiple broadcasts with delays
     */
    private void sendBroadcastsWithDelay() {
        Log.d(TAG, "═══ SCHEDULING BROADCASTS ═══");
        Log.d(TAG, "");

        Handler handler = new Handler(Looper.getMainLooper());

        // Broadcast 1: User data (immediate)
        Log.d(TAG, "Scheduling Broadcast 1: User Data (immediate)");
        sendUserDataBroadcast();

        // Broadcast 2: Notification (after 3 seconds)
        Log.d(TAG, "Scheduling Broadcast 2: Notification (3 seconds)");
        handler.postDelayed(() -> sendNotificationBroadcast(), 3000);

        // Broadcast 3: Complex data (after 6 seconds)
        Log.d(TAG, "Scheduling Broadcast 3: Complex Data (6 seconds)");
        handler.postDelayed(() -> sendComplexDataBroadcast(), 6000);

        Log.d(TAG, "");
        Log.d(TAG, "All broadcasts scheduled");
        Log.d(TAG, "Watch for receiver logs and Toast messages");
        Log.d(TAG, "");
    }

    /**
     * BROADCAST 1: Send user data
     * Demonstrates: String, int, boolean, long data
     */
    private void sendUserDataBroadcast() {
        Log.d(TAG, "");
        Log.d(TAG, "┌─────────────────────────────────────┐");
        Log.d(TAG, "│   SENDING USER DATA BROADCAST       │");
        Log.d(TAG, "└─────────────────────────────────────┘");
        Log.d(TAG, "");

        // Create Intent with custom action
        Intent intent = new Intent(ACTION_USER_DATA);

        // Add String data
        intent.putExtra("user_name", "John Doe");
        intent.putExtra("user_email", "john.doe@example.com");

        // Add int data
        intent.putExtra("user_age", 28);

        // Add boolean data
        intent.putExtra("is_premium", true);

        // Add long data (user ID)
        intent.putExtra("user_id", 123456789L);

        Log.d(TAG, "Intent created with action: " + ACTION_USER_DATA);
        Log.d(TAG, "Data added:");
        Log.d(TAG, "  user_name: John Doe (String)");
        Log.d(TAG, "  user_email: john.doe@example.com (String)");
        Log.d(TAG, "  user_age: 28 (int)");
        Log.d(TAG, "  is_premium: true (boolean)");
        Log.d(TAG, "  user_id: 123456789 (long)");
        Log.d(TAG, "");

        // Send broadcast
        sendBroadcast(intent);

        Log.d(TAG, "✓ Broadcast sent");
        Log.d(TAG, "  Type: Normal broadcast (sendBroadcast)");
        Log.d(TAG, "  Scope: App-wide");
        Log.d(TAG, "");
    }

    /**
     * BROADCAST 2: Send notification data
     * Demonstrates: String data with null checking
     */
    private void sendNotificationBroadcast() {
        Log.d(TAG, "");
        Log.d(TAG, "┌─────────────────────────────────────┐");
        Log.d(TAG, "│   SENDING NOTIFICATION BROADCAST    │");
        Log.d(TAG, "└─────────────────────────────────────┘");
        Log.d(TAG, "");

        // Create Intent
        Intent intent = new Intent(ACTION_NOTIFICATION);

        // Add notification data
        intent.putExtra("notification_title", "New Message");
        intent.putExtra("notification_message", "You have 3 unread messages");
        intent.putExtra("notification_priority", 1);

        Log.d(TAG, "Intent created with action: " + ACTION_NOTIFICATION);
        Log.d(TAG, "Data added:");
        Log.d(TAG, "  notification_title: New Message (String)");
        Log.d(TAG, "  notification_message: You have 3 unread messages (String)");
        Log.d(TAG, "  notification_priority: 1 (int)");
        Log.d(TAG, "");

        // Send broadcast
        sendBroadcast(intent);

        Log.d(TAG, "✓ Broadcast sent");
        Log.d(TAG, "");
    }

    /**
     * BROADCAST 3: Send complex data
     * Demonstrates: double, float, String array, Bundle
     */
    private void sendComplexDataBroadcast() {
        Log.d(TAG, "");
        Log.d(TAG, "┌─────────────────────────────────────┐");
        Log.d(TAG, "│   SENDING COMPLEX DATA BROADCAST    │");
        Log.d(TAG, "└─────────────────────────────────────┘");
        Log.d(TAG, "");

        // Create Intent
        Intent intent = new Intent(ACTION_COMPLEX_DATA);

        // Add double data (price)
        intent.putExtra("price", 99.99);

        // Add float data (rating)
        intent.putExtra("rating", 4.5f);

        // Add String array (tags)
        String[] tags = {"Android", "BroadcastReceiver", "Intent", "Data"};
        intent.putExtra("tags", tags);

        // Add nested Bundle
        Bundle extraBundle = new Bundle();
        extraBundle.putString("product_name", "Premium Course");
        extraBundle.putInt("quantity", 1);
        intent.putExtra("product_details", extraBundle);

        Log.d(TAG, "Intent created with action: " + ACTION_COMPLEX_DATA);
        Log.d(TAG, "Data added:");
        Log.d(TAG, "  price: 99.99 (double)");
        Log.d(TAG, "  rating: 4.5 (float)");
        Log.d(TAG, "  tags: [Android, BroadcastReceiver, Intent, Data] (String[])");
        Log.d(TAG, "  product_details: Bundle with 2 items");
        Log.d(TAG, "");

        // Send broadcast
        sendBroadcast(intent);

        Log.d(TAG, "✓ Broadcast sent");
        Log.d(TAG, "");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        Log.d(TAG, "");
        Log.d(TAG, "MainActivity destroying...");

        // Unregister receiver
        if (customReceiver != null) {
            try {
                unregisterReceiver(customReceiver);
                Log.d(TAG, "✓ BroadcastReceiver unregistered");
            } catch (IllegalArgumentException e) {
                Log.w(TAG, "Receiver was not registered");
            }
        }

        Log.d(TAG, "");
    }
}