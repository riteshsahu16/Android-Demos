package com.example.t22workmanager;

import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.work.Data;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * SimpleWorker - Demonstrates WorkManager Worker class
 *
 * The Worker class is where you define the actual work to be performed.
 * doWork() is called on a background thread automatically by WorkManager.
 *
 * RETURN VALUES:
 * - Result.success() - Work completed successfully
 * - Result.failure() - Work failed permanently
 * - Result.retry() - Work failed, try again with backoff policy
 */
public class SimpleWorker extends Worker {
    private static final String TAG = "SimpleWorker";

    // Input data keys
    public static final String KEY_TASK_TYPE = "task_type";
    public static final String KEY_INPUT_MESSAGE = "input_message";

    // Output data keys
    public static final String KEY_RESULT_MESSAGE = "result_message";
    public static final String KEY_EXECUTION_TIME = "execution_time";

    /**
     * Constructor - Called by WorkManager
     */
    public SimpleWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
        Log.d(TAG, "Worker instantiated");
    }

    /**
     * doWork() - This is where the actual work happens
     *
     * IMPORTANT:
     * - Runs on a BACKGROUND thread (not main thread)
     * - Can be called multiple times if Result.retry() is returned
     * - Should return quickly (for long work, consider ForegroundService)
     * - Can be interrupted if constraints are no longer met
     */
    @NonNull
    @Override
    public Result doWork() {
        Log.d(TAG, "");
        Log.d(TAG, "╔════════════════════════════════════════╗");
        Log.d(TAG, "║   WORKER EXECUTION STARTED             ║");
        Log.d(TAG, "╚════════════════════════════════════════╝");
        Log.d(TAG, "");

        // Get current timestamp
        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                .format(new Date());

        Log.d(TAG, "Execution Time: " + timestamp);
        Log.d(TAG, "Thread: " + Thread.currentThread().getName());
        Log.d(TAG, "Run Attempt: " + getRunAttemptCount());
        Log.d(TAG, "");

        // Get input data passed from the activity
        Data inputData = getInputData();
        String taskType = inputData.getString(KEY_TASK_TYPE);
        String inputMessage = inputData.getString(KEY_INPUT_MESSAGE);

        Log.d(TAG, "Input Data:");
        Log.d(TAG, "  Task Type: " + taskType);
        Log.d(TAG, "  Message: " + inputMessage);
        Log.d(TAG, "");

        // Perform work based on task type
        Result result;
        try {
            if ("LOG".equals(taskType)) {
                result = performLoggingTask(inputMessage);
            } else if ("NETWORK".equals(taskType)) {
                result = performNetworkTask(inputMessage);
            } else {
                result = performDefaultTask(inputMessage);
            }

        } catch (Exception e) {
            Log.e(TAG, "✗ Exception during work execution: " + e.getMessage());
            e.printStackTrace();
            result = Result.failure(createOutputData("Failed: " + e.getMessage(), timestamp));
        }

        Log.d(TAG, "");
        Log.d(TAG, "═══ WORKER EXECUTION COMPLETED ═══");
        Log.d(TAG, "Result: " + result.getClass().getSimpleName());
        Log.d(TAG, "");

        return result;
    }

    /**
     * Perform logging task - Simple message logging
     */
    private Result performLoggingTask(String message) {
        Log.d(TAG, "┌─────────────────────────────────────┐");
        Log.d(TAG, "│   LOGGING TASK                      │");
        Log.d(TAG, "└─────────────────────────────────────┘");
        Log.d(TAG, "");

        Log.d(TAG, "📝 Logging message...");
        Log.d(TAG, "   Message: " + message);

        // Simulate some work
        try {
            Thread.sleep(1000); // 1 second
        } catch (InterruptedException e) {
            Log.w(TAG, "⚠ Work interrupted");
            return Result.retry();
        }

        Log.d(TAG, "✓ Logging task completed successfully");

        String timestamp = new SimpleDateFormat("HH:mm:ss", Locale.getDefault())
                .format(new Date());
        return Result.success(createOutputData("Logged: " + message, timestamp));
    }

    /**
     * Perform network task - Simulated network call
     */
    private Result performNetworkTask(String endpoint) {
        Log.d(TAG, "┌─────────────────────────────────────┐");
        Log.d(TAG, "│   NETWORK TASK (SIMULATED)          │");
        Log.d(TAG, "└─────────────────────────────────────┘");
        Log.d(TAG, "");

        Log.d(TAG, "🌐 Simulating network call...");
        Log.d(TAG, "   Endpoint: " + endpoint);

        // Simulate network latency
        try {
            Log.d(TAG, "   Connecting...");
            Thread.sleep(1000);

            Log.d(TAG, "   Sending request...");
            Thread.sleep(500);

            Log.d(TAG, "   Receiving response...");
            Thread.sleep(500);

        } catch (InterruptedException e) {
            Log.w(TAG, "⚠ Network call interrupted");
            return Result.retry();
        }

        // Simulate success/failure (90% success rate)
        boolean success = Math.random() > 0.1;

        if (success) {
            Log.d(TAG, "✓ Network call successful");
            Log.d(TAG, "   Status: 200 OK");
            Log.d(TAG, "   Response: {\"status\":\"success\",\"data\":\"mock_data\"}");

            String timestamp = new SimpleDateFormat("HH:mm:ss", Locale.getDefault())
                    .format(new Date());
            return Result.success(createOutputData("Network call succeeded", timestamp));

        } else {
            Log.e(TAG, "✗ Network call failed");
            Log.e(TAG, "   Status: 500 Internal Server Error");
            Log.e(TAG, "   Will retry with backoff policy...");

            return Result.retry();
        }
    }

    /**
     * Perform default task
     */
    private Result performDefaultTask(String message) {
        Log.d(TAG, "┌─────────────────────────────────────┐");
        Log.d(TAG, "│   DEFAULT TASK                      │");
        Log.d(TAG, "└─────────────────────────────────────┘");
        Log.d(TAG, "");

        Log.d(TAG, "⚙ Performing default work...");
        Log.d(TAG, "   Input: " + message);

        try {
            Thread.sleep(1500); // 1.5 seconds
        } catch (InterruptedException e) {
            return Result.retry();
        }

        Log.d(TAG, "✓ Default task completed");

        String timestamp = new SimpleDateFormat("HH:mm:ss", Locale.getDefault())
                .format(new Date());
        return Result.success(createOutputData("Work completed", timestamp));
    }

    /**
     * Create output data to return to the caller
     */
    private Data createOutputData(String message, String timestamp) {
        return new Data.Builder()
                .putString(KEY_RESULT_MESSAGE, message)
                .putString(KEY_EXECUTION_TIME, timestamp)
                .build();
    }

    /**
     * onStopped() - Called when work is stopped before completion
     * This happens when constraints are no longer met or work is cancelled
     */
    @Override
    public void onStopped() {
        super.onStopped();
        Log.w(TAG, "");
        Log.w(TAG, "⚠ WORKER STOPPED");
        Log.w(TAG, "  Reason: Constraints no longer met or work cancelled");
        Log.w(TAG, "");
    }
}
