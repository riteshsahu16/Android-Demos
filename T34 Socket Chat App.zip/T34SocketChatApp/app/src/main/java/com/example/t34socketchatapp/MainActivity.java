package com.example.t34socketchatapp;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Locale;

/**
 * Chat Client MainActivity
 *
 * Demonstrates:
 * - Socket connection on background thread
 * - Sending messages via PrintWriter
 * - Receiving messages via BufferedReader
 * - UI updates using Handler
 * - Proper socket lifecycle management
 */


public class MainActivity extends AppCompatActivity {
    private static final String TAG = "ChatClient";
    private static final int SERVER_PORT = 8080;

    // UI Components
    private EditText editServerIp;
    private EditText editMessage;
    private Button btnConnect;
    private Button btnSend;
    private TextView tvStatus;
    private TextView tvMessages;
    private ScrollView scrollMessages;

    // Socket components
    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;

    // Threading
    private Handler uiHandler;
    private Thread connectionThread;
    private Thread receiveThread;

    // State
    private boolean isConnected = false;
    private SimpleDateFormat timeFormat;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        Log.d(TAG, "");
        Log.d(TAG, "╔════════════════════════════════════════╗");
        Log.d(TAG, "║   CHAT CLIENT STARTED                  ║");
        Log.d(TAG, "╚════════════════════════════════════════╝");
        Log.d(TAG, "");

        // Initialize UI
        initializeViews();

        // Initialize Handler for UI updates
        uiHandler = new Handler(Looper.getMainLooper());

        // Initialize time format
        timeFormat = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());

        // Setup listeners
        setupListeners();

        Log.d(TAG, "✓ UI initialized");
        Log.d(TAG, "Ready to connect");
        Log.d(TAG, "");
    }
    /**
     * Initialize UI components
     */
    private void initializeViews() {
        editServerIp = findViewById(R.id.editServerIp);
        editMessage = findViewById(R.id.editMessage);
        btnConnect = findViewById(R.id.btnConnect);
        btnSend = findViewById(R.id.btnSend);
        tvStatus = findViewById(R.id.tvStatus);
        tvMessages = findViewById(R.id.tvMessages);
        scrollMessages = findViewById(R.id.scrollMessages);
    }

    /**
     * Setup button listeners
     */
    private void setupListeners() {
        btnConnect.setOnClickListener(v -> {
            if (!isConnected) {
                connectToServer();
            } else {
                disconnect();
            }
        });

        btnSend.setOnClickListener(v -> sendMessage());
    }

    /**
     * Connect to server on background thread
     *
     * CRITICAL: Network operations MUST run on background thread
     * Running on main thread causes NetworkOnMainThreadException
     */
    private void connectToServer() {
        String serverIp = editServerIp.getText().toString().trim();

        if (serverIp.isEmpty()) {
            showToast("Please enter server IP");
            return;
        }

        Log.d(TAG, "");
        Log.d(TAG, "═══ INITIATING CONNECTION ═══");
        Log.d(TAG, "Server IP: " + serverIp);
        Log.d(TAG, "Port: " + SERVER_PORT);
        Log.d(TAG, "");

        updateStatus("Connecting...");
        btnConnect.setEnabled(false);

        // Create connection thread
        connectionThread = new Thread(() -> {
            try {
                Log.d(TAG, "Background thread started");
                Log.d(TAG, "Thread: " + Thread.currentThread().getName());
                Log.d(TAG, "");

                // Create socket connection
                Log.d(TAG, "Creating socket connection...");
                socket = new Socket(serverIp, SERVER_PORT);

                Log.d(TAG, "✓ Socket created successfully");
                Log.d(TAG, "  Local Address: " + socket.getLocalAddress());
                Log.d(TAG, "  Local Port: " + socket.getLocalPort());
                Log.d(TAG, "  Remote Address: " + socket.getInetAddress());
                Log.d(TAG, "");

                // Setup I/O streams
                Log.d(TAG, "Setting up I/O streams...");
                out = new PrintWriter(socket.getOutputStream(), true);
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

                Log.d(TAG, "✓ I/O streams established");
                Log.d(TAG, "  Output: PrintWriter");
                Log.d(TAG, "  Input: BufferedReader");
                Log.d(TAG, "");

                isConnected = true;

                // Update UI on main thread
                uiHandler.post(() -> {
                    updateStatus("Connected to " + serverIp);
                    btnConnect.setText("Disconnect");
                    btnConnect.setEnabled(true);
                    editMessage.setEnabled(true);
                    btnSend.setEnabled(true);
                    editServerIp.setEnabled(false);

                    appendMessage("=== Connected to server ===\n");
                });

                // Start receiving messages
                startReceivingMessages();

            } catch (IOException e) {
                Log.e(TAG, "✗ Connection failed: " + e.getMessage());
                e.printStackTrace();

                final String errorMsg = e.getMessage();
                uiHandler.post(() -> {
                    updateStatus("Connection failed");
                    btnConnect.setEnabled(true);
                    showToast("Connection error: " + errorMsg);
                });
            }
        });

        connectionThread.start();
    }

    /**
     * Start receiving messages on background thread
     */
    private void startReceivingMessages() {
        Log.d(TAG, "═══ STARTING MESSAGE RECEIVER ═══");
        Log.d(TAG, "");

        receiveThread = new Thread(() -> {
            try {
                Log.d(TAG, "Receive thread started");
                Log.d(TAG, "Listening for messages...");
                Log.d(TAG, "");

                String message;
                while (isConnected && (message = in.readLine()) != null) {
                    Log.d(TAG, "📩 Received: " + message);

                    final String receivedMsg = message;

                    // Update UI on main thread
                    uiHandler.post(() -> {
                        appendMessage(receivedMsg + "\n");
                    });
                }

                Log.d(TAG, "");
                Log.d(TAG, "Receive loop ended");

                // Connection closed
                if (isConnected) {
                    uiHandler.post(() -> {
                        showToast("Disconnected from server");
                        disconnect();
                    });
                }

            } catch (IOException e) {
                if (isConnected) {
                    Log.e(TAG, "✗ Receive error: " + e.getMessage());

                    uiHandler.post(() -> {
                        showToast("Connection lost");
                        disconnect();
                    });
                }
            }
        });

        receiveThread.start();
    }

    /**
     * Send message to server
     */
    private void sendMessage() {
        String message = editMessage.getText().toString().trim();

        if (message.isEmpty()) {
            return;
        }

        if (!isConnected || out == null) {
            showToast("Not connected to server");
            return;
        }

        Log.d(TAG, "");
        Log.d(TAG, "📤 Sending: " + message);

        // Send on background thread
        new Thread(() -> {
            try {
                out.println(message);

                Log.d(TAG, "✓ Message sent");

                // Clear input on UI thread
                uiHandler.post(() -> {
                    editMessage.setText("");
                });

            } catch (Exception e) {
                Log.e(TAG, "✗ Send error: " + e.getMessage());

                uiHandler.post(() -> {
                    showToast("Failed to send message");
                });
            }
        }).start();
    }

    /**
     * Disconnect from server
     */
    private void disconnect() {
        Log.d(TAG, "");
        Log.d(TAG, "═══ DISCONNECTING ═══");

        isConnected = false;

        // Close socket and streams on background thread
        new Thread(() -> {
            try {
                if (out != null) {
                    out.close();
                    Log.d(TAG, "✓ Output stream closed");
                }
                if (in != null) {
                    in.close();
                    Log.d(TAG, "✓ Input stream closed");
                }
                if (socket != null && !socket.isClosed()) {
                    socket.close();
                    Log.d(TAG, "✓ Socket closed");
                }

                Log.d(TAG, "✓ Disconnected successfully");
                Log.d(TAG, "");

            } catch (IOException e) {
                Log.e(TAG, "Error during disconnect: " + e.getMessage());
            }
        }).start();

        // Update UI
        updateStatus("Disconnected");
        btnConnect.setText("Connect");
        btnConnect.setEnabled(true);
        editMessage.setEnabled(false);
        btnSend.setEnabled(false);
        editServerIp.setEnabled(true);

        appendMessage("\n=== Disconnected from server ===\n");
    }

    /**
     * Update status text on UI thread
     */
    private void updateStatus(String status) {
        tvStatus.setText("Status: " + status);
    }

    /**
     * Append message to chat window
     */
    private void appendMessage(String message) {
        tvMessages.append(message);

        // Auto-scroll to bottom
        scrollMessages.post(() -> scrollMessages.fullScroll(View.FOCUS_DOWN));
    }

    /**
     * Show toast message
     */
    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        Log.d(TAG, "");
        Log.d(TAG, "Activity destroying - cleaning up");

        // Disconnect if still connected
        if (isConnected) {
            disconnect();
        }

        Log.d(TAG, "");
    }
}