package com.example.t25networkconnectivityreceiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;
import android.widget.Toast;
/**
 * Network Change BroadcastReceiver (LEGACY APPROACH)
 *
 * IMPORTANT DEPRECATION NOTES:
 * - CONNECTIVITY_CHANGE broadcast is DEPRECATED since Android N (API 24)
 * - Manifest-declared receivers don't receive this broadcast on API 24+
 * - Can still be registered DYNAMICALLY in code for foreground apps
 * - For production apps, use ConnectivityManager.NetworkCallback instead
 *
 * This is provided for LEARNING PURPOSES to understand BroadcastReceivers
 *
 * MODERN ALTERNATIVE: ConnectivityManager.NetworkCallback
 */
public class NetworkChangeReceiver extends BroadcastReceiver {
    private static final String TAG = "NetworkChangeReceiver";

    /**
     * onReceive() - Called when network connectivity changes
     *
     * This method is called on the MAIN THREAD
     * Keep it fast - no long-running operations!
     */
    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d(TAG, "");
        Log.d(TAG, "╔════════════════════════════════════════╗");
        Log.d(TAG, "║   BROADCAST RECEIVED                   ║");
        Log.d(TAG, "╚════════════════════════════════════════╝");
        Log.d(TAG, "");

        // Get the action
        String action = intent.getAction();
        Log.d(TAG, "Action: " + action);

        // Check if it's the connectivity change action
        if (ConnectivityManager.CONNECTIVITY_ACTION.equals(action)) {
            Log.d(TAG, "Network connectivity has changed");
            Log.d(TAG, "");

            // Check current network status
            boolean isConnected = isNetworkConnected(context);
            String connectionType = getConnectionType(context);

            // Log the status
            Log.d(TAG, "Network Status:");
            Log.d(TAG, "  Connected: " + isConnected);
            Log.d(TAG, "  Type: " + connectionType);
            Log.d(TAG, "");

            // Show Toast message
            String message;
            if (isConnected) {
                message = "📶 ONLINE - Connected via " + connectionType;
                Log.d(TAG, "✓ Device is ONLINE");
            } else {
                message = "📵 OFFLINE - No Internet Connection";
                Log.d(TAG, "✗ Device is OFFLINE");
            }

            Toast.makeText(context, message, Toast.LENGTH_LONG).show();
            Log.d(TAG, "Toast displayed: " + message);
            Log.d(TAG, "");
        }
    }

    /**
     * Check if network is connected
     */
    private boolean isNetworkConnected(Context context) {
        ConnectivityManager cm = (ConnectivityManager)
                context.getSystemService(Context.CONNECTIVITY_SERVICE);

        if (cm != null) {
            NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
            return activeNetwork != null && activeNetwork.isConnectedOrConnecting();
        }

        return false;
    }

    /**
     * Get the type of network connection
     */
    private String getConnectionType(Context context) {
        ConnectivityManager cm = (ConnectivityManager)
                context.getSystemService(Context.CONNECTIVITY_SERVICE);

        if (cm != null) {
            NetworkInfo activeNetwork = cm.getActiveNetworkInfo();

            if (activeNetwork != null && activeNetwork.isConnected()) {
                int type = activeNetwork.getType();

                switch (type) {
                    case ConnectivityManager.TYPE_WIFI:
                        return "WiFi";
                    case ConnectivityManager.TYPE_MOBILE:
                        return "Mobile Data";
                    case ConnectivityManager.TYPE_ETHERNET:
                        return "Ethernet";
                    default:
                        return "Other (" + activeNetwork.getTypeName() + ")";
                }
            }
        }

        return "None";
    }
}
