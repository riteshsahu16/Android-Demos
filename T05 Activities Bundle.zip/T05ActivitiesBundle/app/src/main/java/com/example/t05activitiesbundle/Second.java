package com.example.t05activitiesbundle;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Second extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_second);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        TextView textView = findViewById(R.id.textView);
        Bundle bundle  = getIntent().getBundleExtra("userData");
        if(bundle != null){
            String firstName = bundle.getString("first", "");
            String lastName = bundle.getString("last", "");
            String color = bundle.getString("color", "");
            String result = "First Name: " + firstName +
                    "\nLast Name: " + lastName +
                    "\nFavorite Color: " + color;
            textView.setText(result);
        }
    }
}