package com.example.t24jobintentservice;

import android.app.IntentService;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.JobIntentService;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * JobIntentService - Compatibility service for background work
 *
 * IMPORTANT NOTES:
 * - Deprecated in favor of WorkManager
 * - Works as IntentService on pre-Oreo (API < 26)
 * - Works as JobScheduler on Oreo+ (API >= 26)
 * - Handles work sequentially on background thread
 * - Automatically stops when queue is empty
 * - Survives app kill on Oreo+ (work will restart)
 *
 * KEY DIFFERENCES FROM REGULAR SERVICE:
 * - onHandleWork() instead of onStartCommand()
 * - Runs on BACKGROUND THREAD automatically (not main thread)
 * - No need to call stopSelf() (stops automatically)
 * - Use enqueueWork() to add work to queue
 *
 * MIGRATION PATH:
 * IntentService → JobIntentService → WorkManager (recommended)
 */
public class MyJobIntentService extends JobIntentService {
    private static final String TAG = "MyJobIntentService";

    /**
     * Unique job ID for this service
     * Must be unique across your app
     * Used by JobScheduler on Android O+
     */
    private static final int JOB_ID = 1000;

    // Intent action constants
    public static final String ACTION_LOG = "com.example.ACTION_LOG";
    public static final String ACTION_PROCESS_DATA = "com.example.ACTION_PROCESS_DATA";
    public static final String ACTION_SYNC = "com.example.ACTION_SYNC";

    // Intent extra keys
    public static final String EXTRA_MESSAGE = "extra_message";
    public static final String EXTRA_COUNT = "extra_count";
    public static final String EXTRA_DATA = "extra_data";

    /**
     * Static convenience method to enqueue work
     *
     * This is the ONLY way to start a JobIntentService
     * Do NOT use startService() or bindService()
     *
     * @param context Context from calling component
     * @param work Intent containing the work to perform
     */
    public static void enqueueWork(Context context, Intent work) {
        Log.d(TAG, "");
        Log.d(TAG, "═══ ENQUEUING WORK ═══");
        Log.d(TAG, "Action: " + work.getAction());
        Log.d(TAG, "Job ID: " + JOB_ID);
        Log.d(TAG, "Implementation: " + (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? "JobScheduler (Android O+)"
                : "Service (pre-O)"));
        Log.d(TAG, "");

        // Enqueue work to JobIntentService
        // Parameters:
        //   context - Application context
        //   cls - JobIntentService class
        //   jobId - Unique job ID
        //   work - Intent with work details
        enqueueWork(context, MyJobIntentService.class, JOB_ID, work);

        Log.d(TAG, "✓ Work enqueued successfully");
        Log.d(TAG, "  Work will be processed on background thread");
        Log.d(TAG, "");
    }

    /**
     * onCreate() - Called when service is first created
     */
    @Override
    public void onCreate() {
        super.onCreate();

        Log.d(TAG, "");
        Log.d(TAG, "╔════════════════════════════════════════╗");
        Log.d(TAG, "║   JOBINTENTSERVICE CREATED             ║");
        Log.d(TAG, "╚════════════════════════════════════════╝");
        Log.d(TAG, "");
        Log.d(TAG, "Service Type: JobIntentService");
        Log.d(TAG, "Android Version: " + Build.VERSION.SDK_INT);
        Log.d(TAG, "Running as: " + (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? "JobScheduler"
                : "IntentService"));
        Log.d(TAG, "Thread Mode: Background (not main thread)");
        Log.d(TAG, "Work Queue: Sequential (one at a time)");
        Log.d(TAG, "");
    }

    /**
     * onHandleWork() - This is where the actual work happens
     *
     * CRITICAL POINTS:
     * - Runs on BACKGROUND THREAD automatically (unlike regular Service)
     * - Called for each Intent enqueued via enqueueWork()
     * - Work is processed SEQUENTIALLY (one at a time)
     * - Service stops automatically when queue is empty
     * - On Oreo+: If app is killed, work restarts from beginning
     * - Can perform long-running operations safely
     *
     * @param intent Intent containing work details and extras
     */
    @Override
    protected void onHandleWork(@NonNull Intent intent) {
        Log.d(TAG, "");
        Log.d(TAG, "╔════════════════════════════════════════╗");
        Log.d(TAG, "║   HANDLING WORK                        ║");
        Log.d(TAG, "╚════════════════════════════════════════╝");
        Log.d(TAG, "");

        // Get timestamp
        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.getDefault())
                .format(new Date());

        Log.d(TAG, "Started at: " + timestamp);
        Log.d(TAG, "Thread: " + Thread.currentThread().getName() + " (BACKGROUND)");
        Log.d(TAG, "Main Thread: " + (Thread.currentThread().getId() == 1 ? "YES" : "NO"));
        Log.d(TAG, "");

        // Get action from intent
        String action = intent.getAction();
        Log.d(TAG, "Action: " + (action != null ? action : "null"));
        Log.d(TAG, "");

        // Process work based on action
        try {
            if (ACTION_LOG.equals(action)) {
                handleLoggingTask(intent);
            } else if (ACTION_PROCESS_DATA.equals(action)) {
                handleDataProcessing(intent);
            } else if (ACTION_SYNC.equals(action)) {
                handleSyncTask(intent);
            } else {
                handleDefaultTask(intent);
            }

            Log.d(TAG, "");
            Log.d(TAG, "✓ Work completed successfully");

        } catch (Exception e) {
            Log.e(TAG, "");
            Log.e(TAG, "✗ Error during work execution");
            Log.e(TAG, "  Error: " + e.getMessage());
            e.printStackTrace();
        }

        Log.d(TAG, "");
        Log.d(TAG, "═══ WORK FINISHED ═══");
        Log.d(TAG, "Service will continue if more work in queue");
        Log.d(TAG, "Service will stop if queue is empty");
        Log.d(TAG, "");
    }

    /**
     * Handle logging task
     */
    private void handleLoggingTask(Intent intent) {
        Log.d(TAG, "┌─────────────────────────────────────┐");
        Log.d(TAG, "│   LOGGING TASK                      │");
        Log.d(TAG, "└─────────────────────────────────────┘");
        Log.d(TAG, "");

        String message = intent.getStringExtra(EXTRA_MESSAGE);
        int count = intent.getIntExtra(EXTRA_COUNT, 5);

        Log.d(TAG, "Message: " + message);
        Log.d(TAG, "Count: " + count);
        Log.d(TAG, "");

        Log.d(TAG, "📝 Starting logging sequence...");
        for (int i = 1; i <= count; i++) {
            Log.d(TAG, "  [" + i + "/" + count + "] " + message);

            // Simulate work
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                Log.w(TAG, "Logging interrupted");
                break;
            }
        }

        Log.d(TAG, "✓ Logging complete");
    }

    /**
     * Handle data processing task
     */
    private void handleDataProcessing(Intent intent) {
        Log.d(TAG, "┌─────────────────────────────────────┐");
        Log.d(TAG, "│   DATA PROCESSING TASK              │");
        Log.d(TAG, "└─────────────────────────────────────┘");
        Log.d(TAG, "");

        String data = intent.getStringExtra(EXTRA_DATA);

        Log.d(TAG, "Input Data: " + data);
        Log.d(TAG, "");

        try {
            Log.d(TAG, "⚙ Processing steps:");

            Log.d(TAG, "  1. Validating data...");
            Thread.sleep(800);
            Log.d(TAG, "     ✓ Data valid");

            Log.d(TAG, "  2. Parsing data...");
            Thread.sleep(1000);
            Log.d(TAG, "     ✓ Data parsed");

            Log.d(TAG, "  3. Transforming data...");
            Thread.sleep(1200);
            Log.d(TAG, "     ✓ Data transformed");

            Log.d(TAG, "  4. Saving results...");
            Thread.sleep(600);
            Log.d(TAG, "     ✓ Results saved");

            Log.d(TAG, "");
            Log.d(TAG, "✓ Data processing complete");
            Log.d(TAG, "  Total time: ~3.6 seconds");

        } catch (InterruptedException e) {
            Log.w(TAG, "Data processing interrupted");
        }
    }

    /**
     * Handle sync task
     */
    private void handleSyncTask(Intent intent) {
        Log.d(TAG, "┌─────────────────────────────────────┐");
        Log.d(TAG, "│   SYNC TASK                         │");
        Log.d(TAG, "└─────────────────────────────────────┘");
        Log.d(TAG, "");

        int itemCount = intent.getIntExtra(EXTRA_COUNT, 10);

        Log.d(TAG, "Items to sync: " + itemCount);
        Log.d(TAG, "");

        try {
            Log.d(TAG, "🔄 Syncing data...");

            for (int i = 1; i <= itemCount; i++) {
                int progress = (i * 100) / itemCount;
                Log.d(TAG, "  Syncing item " + i + "/" + itemCount + " (" + progress + "%)");
                Thread.sleep(300);
            }

            Log.d(TAG, "");
            Log.d(TAG, "✓ Sync complete");
            Log.d(TAG, "  Items synced: " + itemCount);

        } catch (InterruptedException e) {
            Log.w(TAG, "Sync interrupted");
        }
    }

    /**
     * Handle default/unknown task
     */
    private void handleDefaultTask(Intent intent) {
        Log.d(TAG, "┌─────────────────────────────────────┐");
        Log.d(TAG, "│   DEFAULT TASK                      │");
        Log.d(TAG, "└─────────────────────────────────────┘");
        Log.d(TAG, "");

        Log.d(TAG, "⚙ Performing default background work...");

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            Log.w(TAG, "Work interrupted");
        }

        Log.d(TAG, "✓ Default work complete");
    }

    /**
     * onDestroy() - Called when service is destroyed
     * Only called after all work in queue is completed
     */
    @Override
    public void onDestroy() {
        super.onDestroy();

        Log.d(TAG, "");
        Log.d(TAG, "╔════════════════════════════════════════╗");
        Log.d(TAG, "║   JOBINTENTSERVICE DESTROYED           ║");
        Log.d(TAG, "╚════════════════════════════════════════╝");
        Log.d(TAG, "");
        Log.d(TAG, "Reason: Work queue is empty");
        Log.d(TAG, "All enqueued work has been processed");
        Log.d(TAG, "");
    }

}
