package com.example.t25networkconnectivityreceiver;

import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
/**
 * Main Activity - Demonstrates both network monitoring approaches
 *
 * APPROACH 1 (Legacy): BroadcastReceiver - for learning
 * APPROACH 2 (Modern): NetworkCallback - recommended for production
 */
public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";

    // Legacy approach
    private NetworkChangeReceiver networkReceiver;

    // Modern approach
    private NetworkMonitor networkMonitor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        Log.d(TAG, "");
        Log.d(TAG, "╔════════════════════════════════════════╗");
        Log.d(TAG, "║   NETWORK MONITOR DEMO                 ║");
        Log.d(TAG, "╚════════════════════════════════════════╝");
        Log.d(TAG, "");
        Log.d(TAG, "This demo shows TWO approaches:");
        Log.d(TAG, "  1. BroadcastReceiver (LEGACY - for learning)");
        Log.d(TAG, "  2. NetworkCallback (MODERN - recommended)");
        Log.d(TAG, "");
        Log.d(TAG, "Android Version: " + Build.VERSION.SDK_INT);
        Log.d(TAG, "");

        // Choose which approach to use
        boolean useLegacyApproach = false;  // Set to true to test BroadcastReceiver
        boolean useModernApproach = true;   // Set to true to test NetworkCallback

        if (useLegacyApproach) {
            setupLegacyApproach();
        }

        if (useModernApproach) {
            setupModernApproach();
        }

        Log.d(TAG, "");
        Log.d(TAG, "═══ TESTING INSTRUCTIONS ═══");
        Log.d(TAG, "");
        Log.d(TAG, "1. Keep this app open");
        Log.d(TAG, "2. Toggle WiFi on/off in device settings");
        Log.d(TAG, "3. Toggle Mobile Data on/off");
        Log.d(TAG, "4. Watch for Toast messages and logcat output");
        Log.d(TAG, "");
        Log.d(TAG, "On Emulator:");
        Log.d(TAG, "  • Extended Controls (...) → Cellular → Signal Strength");
        Log.d(TAG, "  • Settings → Network & Internet → WiFi");
        Log.d(TAG, "");
    }

    /**
     * APPROACH 1: Legacy BroadcastReceiver (for learning)
     *
     * IMPORTANT:
     * - DEPRECATED since Android N (API 24)
     * - Registered DYNAMICALLY (not in manifest)
     * - Only works when app is in foreground
     * - For learning BroadcastReceivers concept
     */
    private void setupLegacyApproach() {
        Log.d(TAG, "═══ LEGACY APPROACH: BroadcastReceiver ═══");
        Log.d(TAG, "");
        Log.d(TAG, "⚠ DEPRECATED since Android N (API 24)");
        Log.d(TAG, "  Use this ONLY for learning purposes");
        Log.d(TAG, "");

        // Create receiver
        networkReceiver = new NetworkChangeReceiver();

        // Create intent filter for connectivity changes
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(ConnectivityManager.CONNECTIVITY_ACTION);

        // Register receiver DYNAMICALLY (not in manifest)
        registerReceiver(networkReceiver, intentFilter);

        Log.d(TAG, "✓ BroadcastReceiver registered dynamically");
        Log.d(TAG, "  Action: CONNECTIVITY_ACTION");
        Log.d(TAG, "  Works only while app is in foreground");
        Log.d(TAG, "");
    }

    /**
     * APPROACH 2: Modern NetworkCallback (recommended)
     *
     * RECOMMENDED for production apps
     * - Works reliably on all Android versions
     * - Better battery life
     * - More detailed network information
     * - Not deprecated
     */
    private void setupModernApproach() {
        Log.d(TAG, "═══ MODERN APPROACH: NetworkCallback ═══");
        Log.d(TAG, "");
        Log.d(TAG, "✓ RECOMMENDED for production apps");
        Log.d(TAG, "  Works on API 21+ (Lollipop)");
        Log.d(TAG, "");

        // Create network monitor
        networkMonitor = new NetworkMonitor(this);

        // Start monitoring
        networkMonitor.startMonitoring();

        // Check current status
        boolean isConnected = networkMonitor.isConnected();
        Log.d(TAG, "Current Status: " + (isConnected ? "ONLINE" : "OFFLINE"));
        Log.d(TAG, "");

        // Show initial toast
        String message = isConnected ?
                "📶 Currently ONLINE" :
                "📵 Currently OFFLINE";
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        Log.d(TAG, "");
        Log.d(TAG, "MainActivity destroying...");

        // Unregister legacy receiver
        if (networkReceiver != null) {
            try {
                unregisterReceiver(networkReceiver);
                Log.d(TAG, "✓ BroadcastReceiver unregistered");
            } catch (IllegalArgumentException e) {
                Log.w(TAG, "Receiver was not registered");
            }
        }

        // Stop modern monitor
        if (networkMonitor != null) {
            networkMonitor.stopMonitoring();
            Log.d(TAG, "✓ NetworkMonitor stopped");
        }

        Log.d(TAG, "");
    }
}