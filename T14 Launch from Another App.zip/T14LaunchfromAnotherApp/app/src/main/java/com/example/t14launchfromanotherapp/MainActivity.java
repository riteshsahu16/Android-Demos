package com.example.t14launchfromanotherapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

/**
 * Main launcher activity for Target App
 * Entry point when app is launched from home screen
 */
public class MainActivity extends AppCompatActivity {
    private static final String TAG = "TargetApp-Main";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        Log.d(TAG, "========================================");
        Log.d(TAG, "=== TARGET APP - MAIN ACTIVITY ===");
        Log.d(TAG, "========================================");
        Log.d(TAG, "This app has an EXPORTED activity that can be launched");
        Log.d(TAG, "from other apps.");
        Log.d(TAG, "");
        Log.d(TAG, "Exported Activity: ExportedActivity");
        Log.d(TAG, "Action: android.intent.action.VIEW");
        Log.d(TAG, "Custom Action: com.example.targetapp.ACTION_CUSTOM");
        Log.d(TAG, "Custom Scheme: targetapp://");
        Log.d(TAG, "");
        Log.d(TAG, "Waiting to be launched by another app...");
        Log.d(TAG, "========================================");

        logIntentDetails(getIntent());
    }
    private void logIntentDetails(Intent intent) {
        Log.d(TAG, "--- Intent Details ---");
        Log.d(TAG, "Action: " + intent.getAction());
        Log.d(TAG, "Categories: " + intent.getCategories());
        Log.d(TAG, "Data URI: " + intent.getData());
        Log.d(TAG, "Component: " + intent.getComponent());
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "MainActivity destroyed");
    }
}