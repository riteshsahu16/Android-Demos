package com.example.t16customappclass;

import android.app.Application;
import android.util.Log;

/**
 * Custom Application Class
 *
 * The Application class is the first component created when your app starts
 * and the last one destroyed when your app terminates.
 *
 * Lifecycle:
 * 1. Constructor is called
 * 2. onCreate() is called
 * 3. App components run (Activities, Services, etc.)
 * 4. onTerminate() is called (emulator only, not on real devices)
 *
 * Use cases:
 * - Initialize third-party libraries (Firebase, Crashlytics, etc.)
 * - Set up global app configuration
 * - Create singleton instances (Database, Network client, etc.)
 * - Register lifecycle callbacks
 */
public class MyApp extends Application {
    private static final String TAG = "MyApp";

    /**
     * Constructor - Called BEFORE onCreate()
     * Usually don't need to override this
     */
    public MyApp() {
        super();
        Log.d(TAG, "Constructor called - Application object being created");
    }

    /**
     * onCreate() - First method called when application starts
     *
     * This runs BEFORE any Activity, Service, or BroadcastReceiver
     * Runs on the main thread - keep it fast!
     */
    @Override
    public void onCreate() {
        super.onCreate();

        // Log the required message
        Log.d(TAG, "App Started");

        // Additional logging for learning purposes
        Log.d(TAG, "");
        Log.d(TAG, "=== Application Lifecycle ===");
        Log.d(TAG, "1. ✓ Constructor executed");
        Log.d(TAG, "2. ✓ onCreate() executing now");
        Log.d(TAG, "3.   Waiting for first Activity...");
        Log.d(TAG, "");
        Log.d(TAG, "Application Context: " + getApplicationContext().getClass().getSimpleName());
        Log.d(TAG, "Package Name: " + getPackageName());
        Log.d(TAG, "");
    }

    /**
     * Called when the system is running low on memory
     * Use this to release non-critical resources
     */
    @Override
    public void onLowMemory() {
        super.onLowMemory();
        Log.w(TAG, "⚠ onLowMemory() - System is low on memory!");
        Log.w(TAG, "  Consider releasing caches and non-essential data");
    }

    /**
     * Called when the system needs to trim memory
     * More granular than onLowMemory()
     */
    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        Log.w(TAG, "⚠ onTrimMemory() - Memory trim level: " + level);

        // Different levels indicate different severity
        if (level >= TRIM_MEMORY_MODERATE) {
            Log.w(TAG, "  Memory pressure is moderate or higher");
        }
    }

    /**
     * Called when the application is terminating
     *
     * IMPORTANT: This is NEVER called on real Android devices!
     * Only works in emulator for testing purposes.
     * Don't rely on this for critical cleanup - Android may kill
     * your app process without calling this.
     */
    @Override
    public void onTerminate() {
        super.onTerminate();
        Log.d(TAG, "");
        Log.d(TAG, "onTerminate() called");
        Log.d(TAG, "NOTE: This only works on emulator, never on real devices!");
        Log.d(TAG, "");
    }
}
