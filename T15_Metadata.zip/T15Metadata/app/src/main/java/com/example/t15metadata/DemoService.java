package com.example.t15metadata;

import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;

public class DemoService extends Service {
    private static final String TAG = "MetadataDemo-Service";

    @Override
    public void onCreate() {
        super.onCreate();
        readServiceMetadata();
    }
    private void readServiceMetadata() {
        try {
            PackageManager pm = getPackageManager();
            ServiceInfo info = pm.getServiceInfo(
                    new android.content.ComponentName(this, DemoService.class),
                    PackageManager.GET_META_DATA
            );

            Bundle metadata = info.metaData;
            if (metadata != null) {
                String priority = metadata.getString("service.config.priority");
                int retryCount = metadata.getInt("service.config.retry_count");

                Log.d(TAG, "Service Metadata:");
                Log.d(TAG, "  Priority: " + priority);
                Log.d(TAG, "  Retry Count: " + retryCount);
            }

        } catch (Exception e) {
            Log.e(TAG, "Error reading service metadata: " + e.getMessage());
        }
    }
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
