package com.example.t21servicestimestamp;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Background Service - Timestamp Writer
 *
 * This service demonstrates:
 * 1. Running a background task without visible UI
 * 2. Writing data to internal storage (no permissions needed)
 * 3. Using Handler for periodic task execution
 * 4. Proper service lifecycle management
 *
 * The service writes timestamps to a file every 3 seconds.
 * File location: /data/data/com.example.backgroundservice/files/timestamps.txt
 */

public class TimestampService extends Service {
    private static final String TAG = "TimestampService";

    // File configuration
    private static final String FILENAME = "timestamps.txt";
    private static final int UPDATE_INTERVAL_MS = 3000; // 3 seconds

    // Notification configuration
    private static final String CHANNEL_ID = "TimestampServiceChannel";
    private static final int NOTIFICATION_ID = 200;

    // Handler for periodic task
    private Handler timestampHandler;
    private Runnable timestampRunnable;

    // Statistics
    private int writeCount = 0;
    private long serviceStartTime;

    // Date formatter
    private SimpleDateFormat dateFormat;

    /**
     * onCreate() - Called once when service is first created
     */
    @Override
    public void onCreate() {
        super.onCreate();

        Log.d(TAG, "");
        Log.d(TAG, "╔════════════════════════════════════════╗");
        Log.d(TAG, "║   BACKGROUND SERVICE CREATED           ║");
        Log.d(TAG, "╚════════════════════════════════════════╝");
        Log.d(TAG, "");
        Log.d(TAG, "Service: TimestampService");
        Log.d(TAG, "Purpose: Write timestamps to file periodically");
        Log.d(TAG, "File: " + FILENAME);
        Log.d(TAG, "Interval: " + UPDATE_INTERVAL_MS + "ms (" +
                (UPDATE_INTERVAL_MS / 1000) + " seconds)");
        Log.d(TAG, "");

        // Initialize date formatter
        dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.getDefault());

        // Create notification channel
        createNotificationChannel();

        // Initialize handler
        timestampHandler = new Handler(Looper.getMainLooper());

        // Record start time
        serviceStartTime = System.currentTimeMillis();

        Log.d(TAG, "✓ Service initialization complete");
        Log.d(TAG, "");
    }

    /**
     * onStartCommand() - Called every time startService() is invoked
     */
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "═══ onStartCommand() ═══");
        Log.d(TAG, "Start ID: " + startId);
        Log.d(TAG, "Flags: " + flags);

        // Start as foreground service immediately
        startForeground(NOTIFICATION_ID, createNotification());
        Log.d(TAG, "✓ Foreground service started with notification");
        Log.d(TAG, "");

        // Start the periodic timestamp writing task
        startTimestampTask();

        Log.d(TAG, "Service is now running in background");
        Log.d(TAG, "Writing timestamps every " + (UPDATE_INTERVAL_MS / 1000) + " seconds");
        Log.d(TAG, "");

        // START_STICKY: Service will be restarted if killed by system
        return START_STICKY;
    }

    /**
     * Start the periodic timestamp writing task
     */
    private void startTimestampTask() {
        Log.d(TAG, "┌─────────────────────────────────────┐");
        Log.d(TAG, "│   STARTING PERIODIC TASK            │");
        Log.d(TAG, "└─────────────────────────────────────┘");
        Log.d(TAG, "");

        timestampRunnable = new Runnable() {
            @Override
            public void run() {
                // Write current timestamp to file
                writeTimestampToFile();

                // Schedule next execution
                timestampHandler.postDelayed(this, UPDATE_INTERVAL_MS);
            }
        };

        // Start the first execution
        timestampHandler.post(timestampRunnable);

        Log.d(TAG, "✓ Periodic task started");
        Log.d(TAG, "");
    }

    /**
     * Write current timestamp to file
     */
    private void writeTimestampToFile() {
        writeCount++;

        // Get current timestamp
        String timestamp = dateFormat.format(new Date());

        // Create log entry
        String logEntry = String.format(
                "[%d] %s - Service uptime: %d seconds\n",
                writeCount,
                timestamp,
                (System.currentTimeMillis() - serviceStartTime) / 1000
        );

        Log.d(TAG, "─────────────────────────────────────");
        Log.d(TAG, "Writing timestamp #" + writeCount);
        Log.d(TAG, "Time: " + timestamp);

        try {
            // Write to internal storage
            // MODE_APPEND: Add to existing file instead of overwriting
            FileOutputStream fos = openFileOutput(FILENAME, Context.MODE_APPEND);
            fos.write(logEntry.getBytes());
            fos.flush();
            fos.close();

            Log.d(TAG, "✓ Successfully written to file");
            Log.d(TAG, "  Location: " + getFilesDir() + "/" + FILENAME);
            Log.d(TAG, "  Entry #" + writeCount + " appended");

            // Update notification with count
            updateNotification("Timestamps written: " + writeCount);

            // Optionally read and display file size
            if (writeCount % 10 == 0) { // Every 10 writes
                displayFileInfo();
            }

        } catch (Exception e) {
            Log.e(TAG, "✗ Failed to write to file");
            Log.e(TAG, "  Error: " + e.getMessage());
            e.printStackTrace();
        }

        Log.d(TAG, "");
    }

    /**
     * Display information about the timestamp file
     */
    private void displayFileInfo() {
        try {
            // Get file object
            java.io.File file = new java.io.File(getFilesDir(), FILENAME);

            if (file.exists()) {
                long fileSize = file.length();
                int lineCount = countLines();

                Log.d(TAG, "");
                Log.d(TAG, "┌─── FILE STATISTICS ─────────────────┐");
                Log.d(TAG, "│ File: " + FILENAME);
                Log.d(TAG, "│ Size: " + fileSize + " bytes (" +
                        String.format("%.2f", fileSize / 1024.0) + " KB)");
                Log.d(TAG, "│ Lines: " + lineCount);
                Log.d(TAG, "│ Location: " + file.getAbsolutePath());
                Log.d(TAG, "└─────────────────────────────────────┘");
                Log.d(TAG, "");

                // Display last few lines
                displayLastLines(3);
            }

        } catch (Exception e) {
            Log.e(TAG, "Error getting file info: " + e.getMessage());
        }
    }

    /**
     * Count total lines in file
     */
    private int countLines() {
        int count = 0;
        try {
            FileInputStream fis = openFileInput(FILENAME);
            BufferedReader reader = new BufferedReader(new InputStreamReader(fis));

            while (reader.readLine() != null) {
                count++;
            }

            reader.close();
            fis.close();

        } catch (Exception e) {
            Log.e(TAG, "Error counting lines: " + e.getMessage());
        }
        return count;
    }

    /**
     * Display last N lines from file
     */
    private void displayLastLines(int n) {
        try {
            FileInputStream fis = openFileInput(FILENAME);
            BufferedReader reader = new BufferedReader(new InputStreamReader(fis));

            // Read all lines into a list
            java.util.ArrayList<String> lines = new java.util.ArrayList<>();
            String line;
            while ((line = reader.readLine()) != null) {
                lines.add(line);
            }

            reader.close();
            fis.close();

            // Display last N lines
            Log.d(TAG, "Last " + n + " timestamps:");
            int start = Math.max(0, lines.size() - n);
            for (int i = start; i < lines.size(); i++) {
                Log.d(TAG, "  " + lines.get(i));
            }
            Log.d(TAG, "");

        } catch (Exception e) {
            Log.e(TAG, "Error reading last lines: " + e.getMessage());
        }
    }

    /**
     * Create notification channel (Android 8.0+)
     */
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Log.d(TAG, "Creating notification channel...");

            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Timestamp Service",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Shows timestamp writing status");

            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
                Log.d(TAG, "✓ Notification channel created");
            }
        }
    }

    /**
     * Create notification for foreground service
     */
    private Notification createNotification() {
        return createNotificationWithText("Service running...");
    }

    /**
     * Create notification with custom text
     */
    private Notification createNotificationWithText(String text) {
        // Intent to open MainActivity when notification is tapped
        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this,
                0,
                notificationIntent,
                PendingIntent.FLAG_IMMUTABLE
        );

        // Build notification
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Background Service")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_menu_save)
                .setContentIntent(pendingIntent)
                .setOngoing(true) // Cannot be dismissed while service is running
                .setPriority(NotificationCompat.PRIORITY_LOW);

        return builder.build();
    }

    /**
     * Update notification with new text
     */
    private void updateNotification(String text) {
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager != null) {
            manager.notify(NOTIFICATION_ID, createNotificationWithText(text));
        }
    }

    /**
     * onBind() - Not used for started services
     */
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    /**
     * onDestroy() - Clean up when service is destroyed
     */
    @Override
    public void onDestroy() {
        super.onDestroy();

        Log.d(TAG, "");
        Log.d(TAG, "╔════════════════════════════════════════╗");
        Log.d(TAG, "║   BACKGROUND SERVICE DESTROYING        ║");
        Log.d(TAG, "╚════════════════════════════════════════╝");
        Log.d(TAG, "");

        // Stop periodic task
        if (timestampRunnable != null) {
            timestampHandler.removeCallbacks(timestampRunnable);
            Log.d(TAG, "✓ Periodic task stopped");
        }

        // Display final statistics
        long uptimeSeconds = (System.currentTimeMillis() - serviceStartTime) / 1000;
        Log.d(TAG, "");
        Log.d(TAG, "Service Statistics:");
        Log.d(TAG, "  Total timestamps written: " + writeCount);
        Log.d(TAG, "  Service uptime: " + uptimeSeconds + " seconds");
        Log.d(TAG, "  File location: " + getFilesDir() + "/" + FILENAME);

        // Display final file info
        displayFileInfo();

        // Remove foreground notification
        stopForeground(true);

        Log.d(TAG, "");
        Log.d(TAG, "✓ Service destroyed successfully");
        Log.d(TAG, "");
    }
}
