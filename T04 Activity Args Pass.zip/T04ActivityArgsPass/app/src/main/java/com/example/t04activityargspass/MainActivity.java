package com.example.t04activityargspass;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        EditText editHobbies = findViewById(R.id.etHobbies);
        EditText editFavNumbers = findViewById(R.id.etFavNum);
        Button btnSubmit = findViewById(R.id.button);

        btnSubmit.setOnClickListener(v -> {
            // Collect Input
            String strHobbies = editHobbies.getText().toString();
            String strFavNum = editFavNumbers.getText().toString();

            // Split hobbies
            String[] hobbiesArr = strHobbies.split("\\s*,\\s*");

            // Split favourite number into int[]
            String[] favNumStrArr = strFavNum.split("\\s*,\\s*");
            int[] favNumArr = new int[hobbiesArr.length];
            for (int i = 0; i < favNumArr.length; i++) {
                favNumArr[i] =  Integer.parseInt(favNumStrArr[i]);
            }

            // launch second activity
            Intent intent = new Intent(MainActivity.this, Second.class);
            intent.putExtra("hobbies", hobbiesArr);
            intent.putExtra("favnumbers", favNumArr);
            startActivity(intent);

        });
    }
}