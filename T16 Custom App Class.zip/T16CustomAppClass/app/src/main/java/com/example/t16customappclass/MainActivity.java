package com.example.t16customappclass;

import android.os.Bundle;
import android.util.Log;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    /**
     * Main Activity
     *
     * This activity demonstrates that Application.onCreate()
     * is called BEFORE Activity.onCreate()
     */
    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        Log.d(TAG, "");
        Log.d(TAG, "╔════════════════════════════════════════╗");
        Log.d(TAG, "║     MAIN ACTIVITY CREATED              ║");
        Log.d(TAG, "╚════════════════════════════════════════╝");
        Log.d(TAG, "");
        Log.d(TAG, "Activity lifecycle:");
        Log.d(TAG, "  1. Application.onCreate() was called FIRST");
        Log.d(TAG, "  2. MainActivity.onCreate() is executing NOW");
        Log.d(TAG, "");

        // Access the custom Application instance
        demonstrateApplicationAccess();
    }
    /**
     * Demonstrate accessing the custom Application class
     */
    private void demonstrateApplicationAccess() {
        Log.d(TAG, "--- Accessing Custom Application ---");

        // Get the Application instance (returns MyApp object)
        MyApp app = (MyApp) getApplication();

        Log.d(TAG, "Application class: " + app.getClass().getSimpleName());
        Log.d(TAG, "Application package: " + app.getPackageName());

        // Verify it's our custom class
        if (app instanceof MyApp) {
            Log.d(TAG, "✓ Custom Application class is registered correctly");
        } else {
            Log.e(TAG, "✗ Using default Application class (registration failed)");
        }

        Log.d(TAG, "");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG, "MainActivity onStart()");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "MainActivity onResume() - App is now fully visible");
        Log.d(TAG, "");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "MainActivity onPause()");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "MainActivity onStop()");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "MainActivity onDestroy()");
        Log.d(TAG, "");
    }
}