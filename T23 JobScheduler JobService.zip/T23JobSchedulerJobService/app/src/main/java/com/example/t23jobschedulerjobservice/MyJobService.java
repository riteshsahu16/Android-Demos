package com.example.t23jobschedulerjobservice;

import android.app.Service;
import android.app.job.JobParameters;
import android.app.job.JobService;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * JobService - System-level API for scheduling background jobs
 *
 * IMPORTANT NOTES:
 * - Requires API 21+ (Android 5.0 Lollipop)
 * - onStartJob() runs on MAIN THREAD - spawn background thread for work
 * - Must call jobFinished() when work completes
 * - Return true from onStartJob() if work continues in background
 * - Return false from onStartJob() if work finishes immediately
 * - onStopJob() called if job is cancelled before completion
 * - Return true from onStopJob() to reschedule, false to drop job
 *
 * WorkManager (recommended) is built on top of JobScheduler
 */
public class MyJobService extends JobService {
    private static final String TAG = "MyJobService";

    // Handler for background work
    private Handler backgroundHandler;

    // Track if job is running
    private boolean jobCancelled = false;

    /**
     * onCreate() - Called when service is first created
     */
    @Override
    public void onCreate() {
        super.onCreate();

        Log.d(TAG, "");
        Log.d(TAG, "╔════════════════════════════════════════╗");
        Log.d(TAG, "║   JOB SERVICE CREATED                  ║");
        Log.d(TAG, "╚════════════════════════════════════════╝");
        Log.d(TAG, "");
        Log.d(TAG, "JobService initialized");
        Log.d(TAG, "Waiting for jobs to be scheduled...");
        Log.d(TAG, "");
    }

    /**
     * onStartJob() - Called when the JobScheduler starts your job
     *
     * CRITICAL POINTS:
     * - Runs on MAIN THREAD - do not perform long operations here!
     * - Return true if work will continue on another thread
     * - Return false if work is completed immediately
     * - Must call jobFinished() when work is done if returning true
     *
     * @param params Job parameters from JobScheduler
     * @return true if work continues in background, false if done
     */
    @Override
    public boolean onStartJob(JobParameters params) {
        Log.d(TAG, "");
        Log.d(TAG, "╔════════════════════════════════════════╗");
        Log.d(TAG, "║   JOB STARTED                          ║");
        Log.d(TAG, "╚════════════════════════════════════════╝");
        Log.d(TAG, "");

        // Get job information
        int jobId = params.getJobId();
        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                .format(new Date());

        Log.d(TAG, "Job ID: " + jobId);
        Log.d(TAG, "Started at: " + timestamp);
        Log.d(TAG, "Thread: " + Thread.currentThread().getName() + " (MAIN THREAD)");
        Log.d(TAG, "");

        // Log job extras (custom data passed when scheduling)
        android.os.PersistableBundle extras = params.getExtras();
        if (extras != null && !extras.isEmpty()) {
            Log.d(TAG, "Job Extras:");
            for (String key : extras.keySet()) {
                Object value = extras.get(key);
                Log.d(TAG, "  " + key + " = " + value);
            }
            Log.d(TAG, "");
        }

        // Check if this is a periodic job
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            if (params.getJobId() >= 100) { // Periodic jobs use IDs >= 100 in our demo
                Log.d(TAG, "Job Type: PERIODIC");
            } else {
                Log.d(TAG, "Job Type: ONE-TIME");
            }
        }

        // Reset cancellation flag
        jobCancelled = false;

        // Start work on a background thread
        // This is REQUIRED because onStartJob() runs on main thread
        Log.d(TAG, "Spawning background thread for work execution...");
        startWorkOnBackgroundThread(params);

        // Return true because work will continue on background thread
        // We will call jobFinished() when work completes
        Log.d(TAG, "✓ Returning true (work continues in background)");
        Log.d(TAG, "");

        return true;
    }

    /**
     * Start work on a background thread
     * onStartJob() runs on main thread, so we must offload work
     */
    private void startWorkOnBackgroundThread(final JobParameters params) {
        // Create a new thread for the work
        new Thread(new Runnable() {
            @Override
            public void run() {
                Log.d(TAG, "");
                Log.d(TAG, "─────────────────────────────────────");
                Log.d(TAG, "Background thread started");
                Log.d(TAG, "Thread: " + Thread.currentThread().getName());
                Log.d(TAG, "─────────────────────────────────────");
                Log.d(TAG, "");

                // Perform the actual work
                performWork(params);

                // Check if job was cancelled
                if (!jobCancelled) {
                    Log.d(TAG, "");
                    Log.d(TAG, "Work completed successfully");
                    Log.d(TAG, "Calling jobFinished() to notify system...");

                    // Notify the JobScheduler that work is complete
                    // Parameters:
                    //   params - The job parameters
                    //   needsReschedule - false = job done, true = reschedule with backoff
                    jobFinished(params, false);

                    Log.d(TAG, "✓ jobFinished() called (needsReschedule = false)");
                    Log.d(TAG, "");
                } else {
                    Log.w(TAG, "");
                    Log.w(TAG, "Job was cancelled - jobFinished() not called");
                    Log.w(TAG, "");
                }
            }
        }).start();
    }

    /**
     * Perform the actual work
     * This runs on a background thread
     */
    private void performWork(JobParameters params) {
        int jobId = params.getJobId();

        Log.d(TAG, "┌─────────────────────────────────────┐");
        Log.d(TAG, "│   PERFORMING WORK                   │");
        Log.d(TAG, "└─────────────────────────────────────┘");
        Log.d(TAG, "");

        // Get job type from extras
        String jobType = "DEFAULT";
        android.os.PersistableBundle extras = params.getExtras();
        if (extras != null) {
            jobType = extras.getString("job_type", "DEFAULT");
        }

        Log.d(TAG, "Job Type: " + jobType);
        Log.d(TAG, "");

        // Simulate work based on job type
        try {
            switch (jobType) {
                case "LOGGING":
                    performLoggingTask();
                    break;

                case "NETWORK":
                    performNetworkTask();
                    break;

                case "DATA_SYNC":
                    performDataSyncTask();
                    break;

                default:
                    performDefaultTask();
                    break;
            }

        } catch (InterruptedException e) {
            Log.w(TAG, "⚠ Work interrupted: " + e.getMessage());
        }

        Log.d(TAG, "");
        Log.d(TAG, "✓ Work execution completed");
    }

    /**
     * Logging task simulation
     */
    private void performLoggingTask() throws InterruptedException {
        Log.d(TAG, "📝 Logging Task:");
        for (int i = 1; i <= 5; i++) {
            if (jobCancelled) break;

            Log.d(TAG, "  Log entry " + i + "/5");
            Thread.sleep(500);
        }
    }

    /**
     * Network task simulation
     */
    private void performNetworkTask() throws InterruptedException {
        Log.d(TAG, "🌐 Network Task:");
        Log.d(TAG, "  Connecting to server...");
        Thread.sleep(1000);

        if (!jobCancelled) {
            Log.d(TAG, "  Downloading data...");
            Thread.sleep(1500);
        }

        if (!jobCancelled) {
            Log.d(TAG, "  Processing response...");
            Thread.sleep(500);
        }
    }

    /**
     * Data sync task simulation
     */
    private void performDataSyncTask() throws InterruptedException {
        Log.d(TAG, "🔄 Data Sync Task:");
        Log.d(TAG, "  Checking for updates...");
        Thread.sleep(800);

        if (!jobCancelled) {
            Log.d(TAG, "  Syncing 10 items...");
            for (int i = 1; i <= 10; i++) {
                if (jobCancelled) break;
                Log.d(TAG, "    Synced item " + i + "/10");
                Thread.sleep(200);
            }
        }
    }

    /**
     * Default task simulation
     */
    private void performDefaultTask() throws InterruptedException {
        Log.d(TAG, "⚙ Default Task:");
        Log.d(TAG, "  Performing background work...");
        Thread.sleep(2000);
    }

    /**
     * onStopJob() - Called when job is cancelled before completion
     *
     * REASONS FOR CANCELLATION:
     * - Constraints no longer met (e.g., lost network, device unplugged)
     * - Job exceeded deadline
     * - System needs to free resources
     * - JobScheduler.cancel() was called
     *
     * RETURN VALUES:
     * - true: Reschedule the job (will retry with backoff policy)
     * - false: Drop the job (don't retry)
     *
     * @param params Job parameters
     * @return true to reschedule, false to drop
     */
    @Override
    public boolean onStopJob(JobParameters params) {
        Log.w(TAG, "");
        Log.w(TAG, "╔════════════════════════════════════════╗");
        Log.w(TAG, "║   JOB STOPPED (CANCELLED)              ║");
        Log.w(TAG, "╚════════════════════════════════════════╝");
        Log.w(TAG, "");

        int jobId = params.getJobId();
        Log.w(TAG, "Job ID: " + jobId);
        Log.w(TAG, "Reason: Constraints no longer met or system cancelled");
        Log.w(TAG, "");

        // Set flag to stop work
        jobCancelled = true;

        // Decide whether to reschedule
        // true = reschedule (retry later)
        // false = drop (don't retry)
        boolean shouldReschedule = true;

        Log.w(TAG, "Decision: " + (shouldReschedule ? "RESCHEDULE" : "DROP"));
        Log.w(TAG, "");

        if (shouldReschedule) {
            Log.w(TAG, "Job will be rescheduled with backoff policy");
            Log.w(TAG, "System will retry when constraints are met again");
        } else {
            Log.w(TAG, "Job dropped - will not retry");
        }

        Log.w(TAG, "");

        return shouldReschedule;
    }

    /**
     * onDestroy() - Called when service is destroyed
     */
    @Override
    public void onDestroy() {
        super.onDestroy();

        Log.d(TAG, "");
        Log.d(TAG, "JobService destroyed");
        Log.d(TAG, "");
    }
}
