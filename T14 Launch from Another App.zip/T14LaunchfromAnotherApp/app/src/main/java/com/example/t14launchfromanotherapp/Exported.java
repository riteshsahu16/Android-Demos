package com.example.t14launchfromanotherapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

/**
 * EXPORTED ACTIVITY - Can be launched from other apps
 *
 * Security Considerations:
 * 1. This activity is exposed to ALL apps on the device
 * 2. Malicious apps can launch it with crafted data
 * 3. Always validate incoming intent data
 * 4. Don't expose sensitive operations without permissions
 * 5. Consider adding android:permission to restrict access
 */

public class Exported extends AppCompatActivity {
    private static final String TAG = "TargetApp-Exported";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_exported);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        Log.d(TAG, "");
        Log.d(TAG, "╔════════════════════════════════════════╗");
        Log.d(TAG, "║  EXPORTED ACTIVITY LAUNCHED!          ║");
        Log.d(TAG, "║  Successfully called from external app ║");
        Log.d(TAG, "╚════════════════════════════════════════╝");
        Log.d(TAG, "");

        // Get the intent that launched this activity
        Intent intent = getIntent();

        // Log comprehensive intent details
        logIntentDetails(intent);

        // Validate and process intent data (SECURITY CRITICAL)
        processIntentData(intent);

        // Check who launched this activity
        checkCallingApp();

        Log.d(TAG, "");
        Log.d(TAG, "Exported activity initialization complete");
        Log.d(TAG, "This activity is running in Target App's process");
    }
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Log.d(TAG, "");
        Log.d(TAG, "=== NEW INTENT RECEIVED ===");
        Log.d(TAG, "(Activity was already running, reused)");
        setIntent(intent);
        logIntentDetails(intent);
        processIntentData(intent);
    }

    /**
     * Log detailed information about the received intent
     */
    private void logIntentDetails(Intent intent) {
        Log.d(TAG, "");
        Log.d(TAG, "┌─── Intent Analysis ───────────────────┐");

        // Action
        String action = intent.getAction();
        Log.d(TAG, "│ Action: " + (action != null ? action : "null"));

        // Data URI
        Uri data = intent.getData();
        if (data != null) {
            Log.d(TAG, "│ Data URI: " + data);
            Log.d(TAG, "│   Scheme: " + data.getScheme());
            Log.d(TAG, "│   Host: " + data.getHost());
            Log.d(TAG, "│   Path: " + data.getPath());
            if (data.getQuery() != null) {
                Log.d(TAG, "│   Query: " + data.getQuery());
            }
        } else {
            Log.d(TAG, "│ Data URI: null");
        }

        // Type (MIME type)
        String type = intent.getType();
        Log.d(TAG, "│ MIME Type: " + (type != null ? type : "null"));

        // Categories
        if (intent.getCategories() != null && !intent.getCategories().isEmpty()) {
            Log.d(TAG, "│ Categories:");
            for (String category : intent.getCategories()) {
                Log.d(TAG, "│   - " + category);
            }
        } else {
            Log.d(TAG, "│ Categories: none");
        }
        // Component (who we are)
        if (intent.getComponent() != null) {
            Log.d(TAG, "│ Component:");
            Log.d(TAG, "│   Package: " + intent.getComponent().getPackageName());
            Log.d(TAG, "│   Class: " + intent.getComponent().getClassName());
        }

        // Flags
        int flags = intent.getFlags();
        if (flags != 0) {
            Log.d(TAG, "│ Flags: 0x" + Integer.toHexString(flags));
        }

        // Extras
        Bundle extras = intent.getExtras();
        if (extras != null && !extras.isEmpty()) {
            Log.d(TAG, "│ Extras (" + extras.size() + "):");
            for (String key : extras.keySet()) {
                Object value = extras.get(key);
                Log.d(TAG, "│   " + key + " = " + value +
                        " (" + (value != null ? value.getClass().getSimpleName() : "null") + ")");
            }
        } else {
            Log.d(TAG, "│ Extras: none");
        }

        Log.d(TAG, "└───────────────────────────────────────┘");
        Log.d(TAG, "");
    }
    /**
     * Process and validate intent data
     * SECURITY: Always validate data from external sources!
     */
    private void processIntentData(Intent intent) {
        Log.d(TAG, "--- Processing Intent Data ---");

        String action = intent.getAction();

        if (Intent.ACTION_VIEW.equals(action)) {
            Log.d(TAG, "Processing ACTION_VIEW request");
            handleViewAction(intent);

        } else if ("com.example.targetapp.ACTION_CUSTOM".equals(action)) {
            Log.d(TAG, "Processing CUSTOM action");
            handleCustomAction(intent);

        } else {
            Log.w(TAG, "Unknown action: " + action);
            Log.w(TAG, "No handler defined for this action");
        }
    }

    /**
     * Handle ACTION_VIEW intents
     */
    private void handleViewAction(Intent intent) {
        Uri data = intent.getData();

        if (data != null) {
            String scheme = data.getScheme();

            if ("targetapp".equals(scheme)) {
                Log.d(TAG, "✓ Valid custom scheme: targetapp://");
                Log.d(TAG, "  Processing custom URI: " + data.toString());

                // Example: Parse custom URI
                // targetapp://action?param1=value1&param2=value2
                String path = data.getPath();
                String query = data.getQuery();

                Log.d(TAG, "  Path: " + path);
                Log.d(TAG, "  Query: " + query);

            } else {
                Log.w(TAG, "⚠ Unknown URI scheme: " + scheme);
                Log.w(TAG, "  Expected: targetapp://");
            }
        } else {
            Log.d(TAG, "ACTION_VIEW with no data URI");
        }

        // Check for extra data
        String message = intent.getStringExtra("message");
        if (message != null) {
            Log.d(TAG, "✓ Received message: " + message);
        }
    }

    /**
     * Handle custom action
     */
    private void handleCustomAction(Intent intent) {
        Log.d(TAG, "Custom action handler invoked");

        // Example: Extract custom parameters
        String param1 = intent.getStringExtra("param1");
        String param2 = intent.getStringExtra("param2");
        int numValue = intent.getIntExtra("number", -1);

        Log.d(TAG, "Custom parameters:");
        Log.d(TAG, "  param1: " + param1);
        Log.d(TAG, "  param2: " + param2);
        Log.d(TAG, "  number: " + numValue);
    }

    /**
     * Check who launched this activity (security audit)
     */
    private void checkCallingApp() {
        Log.d(TAG, "");
        Log.d(TAG, "--- Security Check ---");

        // Get calling package (only works if launched with startActivityForResult)
        String callingPackage = getCallingPackage();
        if (callingPackage != null) {
            Log.d(TAG, "Calling package: " + callingPackage);
        } else {
            Log.d(TAG, "Calling package: unknown (launched with startActivity)");
            Log.d(TAG, "Note: Use startActivityForResult to track caller");
        }

        // Log referrer (Android 5.0+)
        Uri referrer = getReferrer();
        if (referrer != null) {
            Log.d(TAG, "Referrer: " + referrer.toString());
        } else {
            Log.d(TAG, "Referrer: not available");
        }

        Log.d(TAG, "");
        Log.d(TAG, "⚠ SECURITY REMINDER:");
        Log.d(TAG, "  This activity is EXPORTED and can be called by ANY app");
        Log.d(TAG, "  Always validate incoming data");
        Log.d(TAG, "  Consider adding android:permission for protection");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG, "ExportedActivity onStart()");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "ExportedActivity onResume() - Now visible");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "ExportedActivity onPause()");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "ExportedActivity onStop()");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "ExportedActivity destroyed");
        Log.d(TAG, "");
    }


    }