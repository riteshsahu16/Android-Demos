package com.example.t15metadata;

import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    /**
     * Demonstrates reading metadata from both Application and Activity levels
     */
    private static final String TAG = "MetadataDemo-Main";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Log.d(TAG, "");
        Log.d(TAG, "═══════════════════════════════════");
        Log.d(TAG, "    MAIN ACTIVITY STARTED");
        Log.d(TAG, "═══════════════════════════════════");
        Log.d(TAG, "");

        // Access application-level metadata
        accessApplicationMetadata();

        // Read activity-specific metadata
        readActivityMetadata();

        // Demonstrate accessing via Application instance
        demonstrateApplicationAccess();
    }
    /**
     * Access application-level metadata
     * (already read in MyApp.onCreate())
     */
    private void accessApplicationMetadata() {
        Log.d(TAG, "--- Accessing Application Metadata ---");

        MyApp app = (MyApp) getApplication();

        String apiKey = app.getMetadataString("app.config.api_key");
        Log.d(TAG, "API Key from Application: " + apiKey);

        int maxItems = app.getMetadataInt("app.config.max_items", 0);
        Log.d(TAG, "Max Items from Application: " + maxItems);

        boolean debugMode = app.getMetadataBoolean("app.config.debug_mode", false);
        Log.d(TAG, "Debug Mode from Application: " + debugMode);

        Log.d(TAG, "");
    }

    /**
     * Read ACTIVITY-LEVEL metadata
     *
     * Each activity can have its own metadata attached
     */
    private void readActivityMetadata() {
        Log.d(TAG, "═══ READING ACTIVITY METADATA ═══");
        Log.d(TAG, "");

        try {
            PackageManager pm = getPackageManager();

            /*
             * GET_META_DATA flag is REQUIRED!
             * getComponentName() returns the ComponentName of this activity
             */
            ActivityInfo activityInfo = pm.getActivityInfo(
                    getComponentName(),
                    PackageManager.GET_META_DATA
            );

            Bundle activityMetadata = activityInfo.metaData;

            if (activityMetadata != null) {
                Log.d(TAG, "✓ Activity metadata found");
                Log.d(TAG, "  Total entries: " + activityMetadata.size());
                Log.d(TAG, "");

                // Read activity-specific values
                String screenType = activityMetadata.getString(
                        "activity.config.screen_type"
                );
                Log.d(TAG, "Screen Type: " + screenType);

                boolean showToolbar = activityMetadata.getBoolean(
                        "activity.config.show_toolbar",
                        true
                );
                Log.d(TAG, "Show Toolbar: " + showToolbar);

                int refreshInterval = activityMetadata.getInt(
                        "activity.config.refresh_interval_sec",
                        0
                );
                Log.d(TAG, "Refresh Interval: " + refreshInterval + " seconds");

                // List all keys
                Log.d(TAG, "");
                Log.d(TAG, "All activity metadata keys:");
                for (String key : activityMetadata.keySet()) {
                    Object value = activityMetadata.get(key);
                    Log.d(TAG, "  - " + key + " = " + value +
                            " (" + (value != null ? value.getClass().getSimpleName() : "null") + ")");
                }

            } else {
                Log.w(TAG, "⚠ Activity metadata is null");
            }

        } catch (PackageManager.NameNotFoundException e) {
            Log.e(TAG, "✗ Activity not found: " + e.getMessage());
        } catch (Exception e) {
            Log.e(TAG, "✗ Error reading activity metadata: " + e.getMessage());
            e.printStackTrace();
        }

        Log.d(TAG, "");
    }

    /**
     * Demonstrate accessing metadata via Application instance
     * This shows how other classes can access app configuration
     */
    private void demonstrateApplicationAccess() {
        Log.d(TAG, "--- Demonstrating Application Access ---");
        Log.d(TAG, "");
        Log.d(TAG, "Any class can access metadata via Application:");
        Log.d(TAG, "");
        Log.d(TAG, "  MyApp app = (MyApp) context.getApplication();");
        Log.d(TAG, "  String value = app.getMetadataString(\"key\");");
        Log.d(TAG, "");
        Log.d(TAG, "This allows centralized configuration management");
        Log.d(TAG, "across your entire app.");
        Log.d(TAG, "");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "MainActivity destroyed");
        Log.d(TAG, "");
    }
}