package com.example.t22workmanager;

import android.os.Bundle;
import android.util.Log;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.lifecycle.Observer;
import androidx.work.Constraints;
import androidx.work.Data;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkInfo;
import androidx.work.WorkManager;

import java.util.UUID;
import java.util.concurrent.TimeUnit;

/**
 * Main Activity - Demonstrates scheduling work with WorkManager
 *
 * Shows:
 * 1. OneTimeWorkRequest - Runs once
 * 2. OneTimeWorkRequest with constraints - Runs when conditions met
 * 3. OneTimeWorkRequest with delay - Runs after specified time
 * 4. PeriodicWorkRequest - Runs periodically (minimum 15 minutes)
 * 5. Observing work status and results
 */
public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";

    // Unique work names
    private static final String PERIODIC_WORK_NAME = "periodic_logging_work";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        Log.d(TAG, "");
        Log.d(TAG, "╔════════════════════════════════════════╗");
        Log.d(TAG, "║   WORKMANAGER DEMO STARTED             ║");
        Log.d(TAG, "╚════════════════════════════════════════╝");
        Log.d(TAG, "");

        // Demonstrate different types of work requests
        demonstrateWorkRequests();
    }
    /**
     * Demonstrate all types of work requests
     */
    private void demonstrateWorkRequests() {
        Log.d(TAG, "═══ SCHEDULING WORK REQUESTS ═══");
        Log.d(TAG, "");

        // 1. Simple OneTimeWorkRequest
        scheduleOneTimeWork();

        // 2. OneTimeWorkRequest with constraints
        scheduleConstrainedWork();

        // 3. OneTimeWorkRequest with initial delay
        scheduleDelayedWork();

        // 4. PeriodicWorkRequest
        schedulePeriodicWork();

        Log.d(TAG, "");
        Log.d(TAG, "All work requests scheduled!");
        Log.d(TAG, "Watch logcat for worker executions");
        Log.d(TAG, "");
    }

    /**
     * 1. Simple OneTimeWorkRequest - Executes immediately
     */
    private void scheduleOneTimeWork() {
        Log.d(TAG, "┌─────────────────────────────────────┐");
        Log.d(TAG, "│   1. SIMPLE ONE-TIME WORK           │");
        Log.d(TAG, "└─────────────────────────────────────┘");
        Log.d(TAG, "");

        // Create input data
        Data inputData = new Data.Builder()
                .putString(SimpleWorker.KEY_TASK_TYPE, "LOG")
                .putString(SimpleWorker.KEY_INPUT_MESSAGE, "Hello from OneTimeWorkRequest!")
                .build();

        // Build OneTimeWorkRequest
        OneTimeWorkRequest workRequest = new OneTimeWorkRequest.Builder(SimpleWorker.class)
                .setInputData(inputData)
                .addTag("one_time_simple")
                .build();

        Log.d(TAG, "OneTimeWorkRequest created:");
        Log.d(TAG, "  ID: " + workRequest.getId());
        Log.d(TAG, "  Task: LOG");
        Log.d(TAG, "  Execution: Immediate");
        Log.d(TAG, "");

        // Enqueue the work
        WorkManager.getInstance(this).enqueue(workRequest);

        // Observe work status
        observeWork(workRequest.getId(), "Simple One-Time Work");

        Log.d(TAG, "✓ Work enqueued (will execute immediately)");
        Log.d(TAG, "");
    }

    /**
     * 2. OneTimeWorkRequest with CONSTRAINTS
     * Only executes when specified conditions are met
     */
    private void scheduleConstrainedWork() {
        Log.d(TAG, "┌─────────────────────────────────────┐");
        Log.d(TAG, "│   2. CONSTRAINED ONE-TIME WORK      │");
        Log.d(TAG, "└─────────────────────────────────────┘");
        Log.d(TAG, "");

        // Define constraints
        Constraints constraints = new Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)  // Any network connection
                .setRequiresBatteryNotLow(true)                 // Battery not low
                .setRequiresStorageNotLow(true)                 // Storage not low
                .build();

        Log.d(TAG, "Constraints defined:");
        Log.d(TAG, "  ✓ Network: CONNECTED (any connection)");
        Log.d(TAG, "  ✓ Battery: Not Low");
        Log.d(TAG, "  ✓ Storage: Not Low");
        Log.d(TAG, "");
        Log.d(TAG, "Work will ONLY execute when ALL constraints are met");
        Log.d(TAG, "");

        // Create input data
        Data inputData = new Data.Builder()
                .putString(SimpleWorker.KEY_TASK_TYPE, "NETWORK")
                .putString(SimpleWorker.KEY_INPUT_MESSAGE, "https://api.example.com/data")
                .build();

        // Build constrained work request
        OneTimeWorkRequest workRequest = new OneTimeWorkRequest.Builder(SimpleWorker.class)
                .setInputData(inputData)
                .setConstraints(constraints)
                .addTag("one_time_constrained")
                .build();

        Log.d(TAG, "Constrained WorkRequest created:");
        Log.d(TAG, "  ID: " + workRequest.getId());
        Log.d(TAG, "  Task: NETWORK");
        Log.d(TAG, "  Execution: When constraints satisfied");
        Log.d(TAG, "");

        // Enqueue the work
        WorkManager.getInstance(this).enqueue(workRequest);

        // Observe work status
        observeWork(workRequest.getId(), "Constrained Work");

        Log.d(TAG, "✓ Work enqueued (waiting for constraints)");
        Log.d(TAG, "");
    }

    /**
     * 3. OneTimeWorkRequest with INITIAL DELAY
     * Executes after a specified delay
     */
    private void scheduleDelayedWork() {
        Log.d(TAG, "┌─────────────────────────────────────┐");
        Log.d(TAG, "│   3. DELAYED ONE-TIME WORK          │");
        Log.d(TAG, "└─────────────────────────────────────┘");
        Log.d(TAG, "");

        int delaySeconds = 10;

        // Create input data
        Data inputData = new Data.Builder()
                .putString(SimpleWorker.KEY_TASK_TYPE, "LOG")
                .putString(SimpleWorker.KEY_INPUT_MESSAGE, "Delayed execution after " + delaySeconds + " seconds")
                .build();

        // Build delayed work request
        OneTimeWorkRequest workRequest = new OneTimeWorkRequest.Builder(SimpleWorker.class)
                .setInputData(inputData)
                .setInitialDelay(delaySeconds, TimeUnit.SECONDS)
                .addTag("one_time_delayed")
                .build();

        Log.d(TAG, "Delayed WorkRequest created:");
        Log.d(TAG, "  ID: " + workRequest.getId());
        Log.d(TAG, "  Task: LOG");
        Log.d(TAG, "  Delay: " + delaySeconds + " seconds");
        Log.d(TAG, "  Execution: After delay expires");
        Log.d(TAG, "");

        // Enqueue the work
        WorkManager.getInstance(this).enqueue(workRequest);

        // Observe work status
        observeWork(workRequest.getId(), "Delayed Work");

        Log.d(TAG, "✓ Work enqueued (will execute in " + delaySeconds + " seconds)");
        Log.d(TAG, "");
    }

    /**
     * 4. PeriodicWorkRequest - Executes periodically
     *
     * IMPORTANT: Minimum repeat interval is 15 MINUTES
     * Cannot be less than 15 minutes due to system optimizations
     */
    private void schedulePeriodicWork() {
        Log.d(TAG, "┌─────────────────────────────────────┐");
        Log.d(TAG, "│   4. PERIODIC WORK                  │");
        Log.d(TAG, "└─────────────────────────────────────┘");
        Log.d(TAG, "");

        // Create input data
        Data inputData = new Data.Builder()
                .putString(SimpleWorker.KEY_TASK_TYPE, "LOG")
                .putString(SimpleWorker.KEY_INPUT_MESSAGE, "Periodic execution")
                .build();

        // Build periodic work request (minimum 15 minutes)
        PeriodicWorkRequest periodicWork = new PeriodicWorkRequest.Builder(
                SimpleWorker.class,
                15,                    // Repeat interval
                TimeUnit.MINUTES       // Time unit
        )
                .setInputData(inputData)
                .addTag("periodic_work")
                .build();

        Log.d(TAG, "PeriodicWorkRequest created:");
        Log.d(TAG, "  ID: " + periodicWork.getId());
        Log.d(TAG, "  Task: LOG");
        Log.d(TAG, "  Interval: 15 minutes (minimum allowed)");
        Log.d(TAG, "  Repeats: Until cancelled");
        Log.d(TAG, "");
        Log.d(TAG, "Note: Minimum periodic interval is 15 minutes");
        Log.d(TAG, "      due to system battery optimizations");
        Log.d(TAG, "");

        // Enqueue unique periodic work (replaces if already exists)
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
                PERIODIC_WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,  // Keep existing work if already scheduled
                periodicWork
        );

        Log.d(TAG, "✓ Periodic work enqueued");
        Log.d(TAG, "  First execution: In ~15 minutes");
        Log.d(TAG, "  Subsequent: Every 15 minutes");
        Log.d(TAG, "");

        // Note: For demo purposes, this would take too long to observe
        // In production, periodic work is for tasks like syncing data daily
        Log.d(TAG, "⚠ Periodic work takes 15+ minutes to observe");
        Log.d(TAG, "  For this demo, focus on OneTime requests");
        Log.d(TAG, "");
    }

    /**
     * Observe work status and results using LiveData
     */
    private void observeWork(UUID workId, String workName) {
        WorkManager.getInstance(this)
                .getWorkInfoByIdLiveData(workId)
                .observe(this, new Observer<WorkInfo>() {
                    @Override
                    public void onChanged(WorkInfo workInfo) {
                        if (workInfo != null) {
                            WorkInfo.State state = workInfo.getState();

                            Log.d(TAG, "─────────────────────────────────────");
                            Log.d(TAG, "Work Status Update: " + workName);
                            Log.d(TAG, "  ID: " + workId);
                            Log.d(TAG, "  State: " + state);

                            // Check if work is finished
                            if (state.isFinished()) {
                                if (state == WorkInfo.State.SUCCEEDED) {
                                    // Get output data
                                    Data outputData = workInfo.getOutputData();
                                    String resultMessage = outputData.getString(
                                            SimpleWorker.KEY_RESULT_MESSAGE
                                    );
                                    String executionTime = outputData.getString(
                                            SimpleWorker.KEY_EXECUTION_TIME
                                    );

                                    Log.d(TAG, "  ✓ Result: SUCCESS");
                                    Log.d(TAG, "  Message: " + resultMessage);
                                    Log.d(TAG, "  Executed at: " + executionTime);

                                } else if (state == WorkInfo.State.FAILED) {
                                    Log.e(TAG, "  ✗ Result: FAILED");

                                } else if (state == WorkInfo.State.CANCELLED) {
                                    Log.w(TAG, "  ⚠ Result: CANCELLED");
                                }
                            } else {
                                // Work is still in progress
                                Log.d(TAG, "  Status: " + state);
                                if (state == WorkInfo.State.BLOCKED) {
                                    Log.d(TAG, "  Reason: Waiting for constraints");
                                }
                            }

                            Log.d(TAG, "─────────────────────────────────────");
                            Log.d(TAG, "");
                        }
                    }
                });
    }

    /**
     * Cancel periodic work when activity is destroyed
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();

        Log.d(TAG, "");
        Log.d(TAG, "MainActivity destroyed");

        // Optional: Cancel periodic work
        // Uncomment to cancel when activity closes
        /*
        Log.d(TAG, "Cancelling periodic work...");
        WorkManager.getInstance(this).cancelUniqueWork(PERIODIC_WORK_NAME);
        Log.d(TAG, "✓ Periodic work cancelled");
        */

        Log.d(TAG, "Note: Scheduled work continues even after activity closes");
        Log.d(TAG, "");
    }
}