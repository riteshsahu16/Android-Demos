package com.example.t11permissions;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "PermissionsDemo";

    // Request codes for different permissions
    private static final int REQUEST_LOCATION = 100;
    private static final int REQUEST_CONTACTS = 101;
    private static final int REQUEST_MULTIPLE = 102;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        Log.d(TAG, "=== Permissions Demo Started ===");

        // Check and demonstrate INTERNET permission (Normal - always granted)
        checkInternetPermission();

        // Check and request LOCATION permission (Dangerous - needs runtime request)
       // checkLocationPermission();

        // Check and request CONTACTS permission (Dangerous - needs runtime request)
        //checkContactsPermission();

        // Alternative: Request multiple permissions at once
         requestMultiplePermissions();

    }

    /**
     * INTERNET is a normal permission - automatically granted at install
     * No runtime check needed, but we can verify it's in the manifest
     */
    private void checkInternetPermission() {
        Log.d(TAG, "--- Checking INTERNET Permission ---");
        Log.d(TAG, "INTERNET permission is a NORMAL permission");
        Log.d(TAG, "Automatically granted - no runtime request needed");
        Log.d(TAG, "Use case: Network calls, downloading data, API requests");

        // Note: You can directly make network calls without checking
        // Example: HttpURLConnection, OkHttp, Retrofit, etc.
    }

/**
 * ACCESS_FINE_LOCATION is a dangerous permission - requires runtime request
 */
private void checkLocationPermission() {
    Log.d(TAG, "--- Checking LOCATION Permission ---");

    // Check if permission is already granted
    if (ContextCompat.checkSelfPermission(this,
            Manifest.permission.ACCESS_FINE_LOCATION)
            == PackageManager.PERMISSION_GRANTED) {

        Log.d(TAG, "LOCATION permission already granted");
        useLocationFeature();

    } else {
        Log.d(TAG, "LOCATION permission not granted - requesting now");

        // Check if we should show rationale (user previously denied)
        if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                Manifest.permission.ACCESS_FINE_LOCATION)) {
            Log.d(TAG, "Showing rationale: User needs explanation why we need location");
        }

        // Request the permission
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                REQUEST_LOCATION);
    }


}

    /**
     * READ_CONTACTS is a dangerous permission - requires runtime request
     */
    void checkContactsPermission () {
        Log.d(TAG, "--- Checking CONTACTS Permission ---");

        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_CONTACTS)
                == PackageManager.PERMISSION_GRANTED) {

            Log.d(TAG, "CONTACTS permission already granted");
            useContactsFeature();

        } else {
            Log.d(TAG, "CONTACTS permission not granted - requesting now");

            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.READ_CONTACTS)) {
                Log.d(TAG, "Showing rationale: User needs explanation why we need contacts");
            }

            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.READ_CONTACTS},
                    REQUEST_CONTACTS);
        }
    }

    /**
     * Alternative approach: Request multiple permissions at once
     */
    private void requestMultiplePermissions() {
        Log.d(TAG, "--- Requesting Multiple Permissions ---");

        String[] permissions = {
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.READ_CONTACTS
        };

        ActivityCompat.requestPermissions(this, permissions, REQUEST_MULTIPLE);
    }

    /**
     * Handle permission request results
     */
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        Log.d(TAG, "=== Permission Result Received ===");
        Log.d(TAG, "Request Code: " + requestCode);

        switch (requestCode) {
            case REQUEST_LOCATION:
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Log.d(TAG, "✓ LOCATION permission GRANTED by user");
                    useLocationFeature();
                } else {
                    Log.d(TAG, "✗ LOCATION permission DENIED by user");
                    Log.d(TAG, "Location features will be disabled");
                }
                break;

            case REQUEST_CONTACTS:
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Log.d(TAG, "✓ CONTACTS permission GRANTED by user");
                    useContactsFeature();
                } else {
                    Log.d(TAG, "✗ CONTACTS permission DENIED by user");
                    Log.d(TAG, "Contacts features will be disabled");
                }
                break;

            case REQUEST_MULTIPLE:
                handleMultiplePermissionsResult(permissions, grantResults);
                break;
        }
    }

    /**
     * Handle multiple permissions result
     */
    private void handleMultiplePermissionsResult(String[] permissions,
                                                 int[] grantResults) {
        for (int i = 0; i < permissions.length; i++) {
            if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                Log.d(TAG, "✓ " + permissions[i] + " GRANTED");
            } else {
                Log.d(TAG, "✗ " + permissions[i] + " DENIED");
            }
        }
    }

    /**
     * Demonstrate using location permission
     */
    private void useLocationFeature() {
        Log.d(TAG, "--- Using Location Feature ---");
        try {
            LocationManager locationManager =
                    (LocationManager) getSystemService(LOCATION_SERVICE);

            // This would normally throw SecurityException if permission not granted
            Location lastLocation = locationManager.getLastKnownLocation(
                    LocationManager.GPS_PROVIDER);

            if (lastLocation != null) {
                Log.d(TAG, "Last known location: Lat=" + lastLocation.getLatitude()
                        + ", Lon=" + lastLocation.getLongitude());
            } else {
                Log.d(TAG, "No last known location available");
            }

            Log.d(TAG, "Location features available for: GPS tracking, maps, geofencing");

        } catch (SecurityException e) {
            Log.e(TAG, "Security exception accessing location: " + e.getMessage());
        }
    }

    /**
     * Demonstrate using contacts permission
     */
    private void useContactsFeature() {
        Log.d(TAG, "--- Using Contacts Feature ---");
        try {
            Cursor cursor = getContentResolver().query(
                    ContactsContract.Contacts.CONTENT_URI,
                    null, null, null, null);

            if (cursor != null) {
                int count = cursor.getCount();
                Log.d(TAG, "Total contacts found: " + count);

                // Read first 3 contacts as example
                int shown = 0;
                while (cursor.moveToNext() && shown < 3) {
                    int nameIndex = cursor.getColumnIndex(
                            ContactsContract.Contacts.DISPLAY_NAME);
                    if (nameIndex >= 0) {
                        String name = cursor.getString(nameIndex);
                        Log.d(TAG, "Contact " + (shown + 1) + ": " + name);
                        shown++;
                    }
                }
                cursor.close();

                Log.d(TAG, "Contacts features available for: auto-fill, contact picker, social features");
            }

        } catch (SecurityException e) {
            Log.e(TAG, "Security exception accessing contacts: " + e.getMessage());
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "=== Permissions Demo Ended ===");
    }


}
