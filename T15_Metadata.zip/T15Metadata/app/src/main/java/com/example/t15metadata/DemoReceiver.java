package com.example.t15metadata;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;

public class DemoReceiver extends BroadcastReceiver {
    private static final String TAG = "MetadataDemo-Receiver";
    @Override
    public void onReceive(Context context, Intent intent) {
        try {
            PackageManager pm = context.getPackageManager();
            ComponentName component = new ComponentName(context, DemoReceiver.class);

            ActivityInfo info = pm.getReceiverInfo(
                    component,
                    PackageManager.GET_META_DATA
            );

            Bundle metadata = info.metaData;
            if (metadata != null) {
                String channelId = metadata.getString("receiver.config.channel_id");

                Log.d(TAG, "Receiver Metadata:");
                Log.d(TAG, "  Channel ID: " + channelId);
            }

        } catch (Exception e) {
            Log.e(TAG, "Error reading receiver metadata: " + e.getMessage());
        }
    }
}
