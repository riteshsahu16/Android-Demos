import java.io.*;
import java.net.*;
import java.util.*;
import java.text.SimpleDateFormat;

/**
 * Simple Chat Server
 * 
 * Run this on your computer:
 * 1. javac ChatServer.java
 * 2. java ChatServer
 * 3. Server will start on port 8080
 * 4. Connect Android client to your computer's IP address
 */
public class ChatServer {
    private static final int PORT = 8080;
    private static List<ClientHandler> clients = new ArrayList<>();
    private static int clientIdCounter = 1;
    
    public static void main(String[] args) {
        System.out.println("╔════════════════════════════════════════╗");
        System.out.println("║     CHAT SERVER STARTING               ║");
        System.out.println("╚════════════════════════════════════════╝");
        System.out.println();
        
        try {
            ServerSocket serverSocket = new ServerSocket(PORT);
            System.out.println("✓ Server started successfully");
            System.out.println("  Port: " + PORT);
            System.out.println("  Listening for connections...");
            System.out.println();
            
            // Get server's IP address
            InetAddress localhost = InetAddress.getLocalHost();
            System.out.println("Server IP Address: " + localhost.getHostAddress());
            System.out.println("Connect Android clients to this IP");
            System.out.println();
            System.out.println("═══════════════════════════════════════");
            System.out.println();
            
            // Accept client connections
            while (true) {
                Socket clientSocket = serverSocket.accept();
                String clientAddress = clientSocket.getInetAddress().getHostAddress();
                
                System.out.println("═══ NEW CLIENT CONNECTION ═══");
                System.out.println("Client Address: " + clientAddress);
                System.out.println("Client Port: " + clientSocket.getPort());
                
                // Create handler for this client
                ClientHandler clientHandler = new ClientHandler(clientSocket, clientIdCounter++);
                clients.add(clientHandler);
                
                // Start handler thread
                new Thread(clientHandler).start();
                
                System.out.println("✓ Client handler created");
                System.out.println("  Total clients: " + clients.size());
                System.out.println();
            }
            
        } catch (IOException e) {
            System.err.println("✗ Server error: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Broadcast message to all connected clients
     */
    public static synchronized void broadcast(String message, ClientHandler sender) {
        System.out.println("Broadcasting: " + message);
        
        Iterator<ClientHandler> iterator = clients.iterator();
        while (iterator.hasNext()) {
            ClientHandler client = iterator.next();
            
            // Send to all clients except sender
            if (client != sender) {
                boolean sent = client.sendMessage(message);
                if (!sent) {
                    System.out.println("⚠ Failed to send to client " + client.getClientId());
                    iterator.remove();
                }
            }
        }
    }
    
    /**
     * Remove disconnected client
     */
    public static synchronized void removeClient(ClientHandler client) {
        clients.remove(client);
        System.out.println("Client removed. Total clients: " + clients.size());
    }
    
    /**
     * Client Handler - Handles individual client connections
     */
    static class ClientHandler implements Runnable {
        private Socket socket;
        private PrintWriter out;
        private BufferedReader in;
        private int clientId;
        private String clientName;
        private SimpleDateFormat timeFormat;
        
        public ClientHandler(Socket socket, int clientId) {
            this.socket = socket;
            this.clientId = clientId;
            this.timeFormat = new SimpleDateFormat("HH:mm:ss");
        }
        
        @Override
        public void run() {
            try {
                // Setup I/O streams
                out = new PrintWriter(socket.getOutputStream(), true);
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                
                System.out.println("Client " + clientId + " I/O streams established");
                
                // Request client name
                out.println("SERVER: Welcome! Please enter your name:");
                clientName = in.readLine();
                
                if (clientName == null || clientName.trim().isEmpty()) {
                    clientName = "User" + clientId;
                }
                
                System.out.println("Client " + clientId + " identified as: " + clientName);
                
                // Send welcome message
                out.println("SERVER: Welcome, " + clientName + "! You are connected.");
                
                // Broadcast join message
                String joinMessage = "SERVER: " + clientName + " has joined the chat";
                broadcast(joinMessage, this);
                
                // Listen for messages
                String inputLine;
                while ((inputLine = in.readLine()) != null) {
                    String timestamp = timeFormat.format(new Date());
                    String fullMessage = "[" + timestamp + "] " + clientName + ": " + inputLine;
                    
                    System.out.println(fullMessage);
                    
                    // Broadcast to all other clients
                    broadcast(fullMessage, this);
                }
                
            } catch (IOException e) {
                System.out.println("✗ Client " + clientId + " error: " + e.getMessage());
            } finally {
                // Cleanup
                disconnect();
            }
        }
        
        /**
         * Send message to this client
         */
        public boolean sendMessage(String message) {
            try {
                if (out != null) {
                    out.println(message);
                    return true;
                }
            } catch (Exception e) {
                System.err.println("Error sending to client " + clientId + ": " + e.getMessage());
            }
            return false;
        }
        
        /**
         * Disconnect client
         */
        private void disconnect() {
            try {
                System.out.println("═══ CLIENT DISCONNECTING ═══");
                System.out.println("Client: " + clientName + " (ID: " + clientId + ")");
                
                // Broadcast leave message
                String leaveMessage = "SERVER: " + clientName + " has left the chat";
                broadcast(leaveMessage, this);
                
                // Close streams
                if (in != null) in.close();
                if (out != null) out.close();
                if (socket != null) socket.close();
                
                // Remove from clients list
                removeClient(this);
                
                System.out.println("✓ Client disconnected successfully");
                System.out.println();
                
            } catch (IOException e) {
                System.err.println("Error during disconnect: " + e.getMessage());
            }
        }
        
        public int getClientId() {
            return clientId;
        }
    }
}
