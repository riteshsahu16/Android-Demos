package com.example.t35socketstockticker;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.UnknownHostException;

/**
 * Stock Ticker Client - Receives real-time stock updates
 */
public class MainActivity extends AppCompatActivity {
    private static final String TAG = "StockTicker";
    private static final int SERVER_PORT = 8080;

    // UI Components
    private EditText editServerIp;
    private Button btnConnect;
    private TextView tvStatus;
    private TextView tvLastUpdate;
    private RecyclerView recyclerView;
    private StockAdapter adapter;

    // Socket components
    private Socket socket;
    private BufferedReader in;

    // Threading
    private Handler uiHandler;
    private Thread connectionThread;
    private Thread receiveThread;

    // State
    private boolean isConnected = false;
    private int updateCount = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        Log.d(TAG, "");
        Log.d(TAG, "╔════════════════════════════════════════╗");
        Log.d(TAG, "║   STOCK TICKER CLIENT STARTED          ║");
        Log.d(TAG, "╚════════════════════════════════════════╝");
        Log.d(TAG, "");

        initializeViews();
        setupRecyclerView();
        setupListeners();

        uiHandler = new Handler(Looper.getMainLooper());

        Log.d(TAG, "✓ UI initialized");
        Log.d(TAG, "Ready to connect");
        Log.d(TAG, "");
    }
    /**
     * Initialize UI components
     */
    private void initializeViews() {
        editServerIp = findViewById(R.id.editServerIp);
        btnConnect = findViewById(R.id.btnConnect);
        tvStatus = findViewById(R.id.tvStatus);
        tvLastUpdate = findViewById(R.id.tvLastUpdate);
        recyclerView = findViewById(R.id.recyclerView);
    }

    /**
     * Setup RecyclerView
     */
    private void setupRecyclerView() {
        adapter = new StockAdapter();
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
    }

    /**
     * Setup listeners
     */
    private void setupListeners() {
        btnConnect.setOnClickListener(v -> {
            if (!isConnected) {
                connectToServer();
            } else {
                disconnect();
            }
        });
    }

    /**
     * Connect to server
     */
    private void connectToServer() {
        String serverIp = editServerIp.getText().toString().trim();

        if (serverIp.isEmpty()) {
            showToast("Please enter server IP");
            return;
        }

        Log.d(TAG, "═══ CONNECTING TO SERVER ═══");
        Log.d(TAG, "Server: " + serverIp + ":" + SERVER_PORT);
        Log.d(TAG, "");

        updateStatus("Connecting...");
        btnConnect.setEnabled(false);

        connectionThread = new Thread(() -> {
            try {
                Log.d(TAG, "Connection thread started");
                Log.d(TAG, "Thread: " + Thread.currentThread().getName());

                // Create socket
                socket = new Socket(serverIp, SERVER_PORT);

                Log.d(TAG, "✓ Socket connected");
                Log.d(TAG, "  Local: " + socket.getLocalAddress());
                Log.d(TAG, "  Remote: " + socket.getInetAddress());
                Log.d(TAG, "");

                // Setup input stream
                in = new BufferedReader(new InputStreamReader(
                        socket.getInputStream()));

                Log.d(TAG, "✓ Input stream established");
                Log.d(TAG, "");

                isConnected = true;

                // Update UI
                uiHandler.post(() -> {
                    updateStatus("Connected - Receiving live data");
                    btnConnect.setText("Disconnect");
                    btnConnect.setEnabled(true);
                    editServerIp.setEnabled(false);
                });

                // Start receiving data
                startReceivingData();

            } catch (IOException e) {
                Log.e(TAG, "✗ Connection failed: " + e.getMessage());

                uiHandler.post(() -> {
                    updateStatus("Connection failed");
                    btnConnect.setEnabled(true);
                    showToast("Connection error: " + e.getMessage());
                });
            }
        });

        connectionThread.start();
    }

    /**
     * Start receiving continuous data from server
     */
    private void startReceivingData() {
        Log.d(TAG, "═══ STARTING DATA RECEIVER ═══");
        Log.d(TAG, "Listening for stock updates...");
        Log.d(TAG, "");

        receiveThread = new Thread(() -> {
            try {
                String line;
                while (isConnected && (line = in.readLine()) != null) {
                    updateCount++;

                    Log.d(TAG, "📊 Update #" + updateCount + ": " + line);

                    // Parse stock data: SYMBOL|PRICE|TIMESTAMP
                    parseAndUpdateStock(line);
                }

                Log.d(TAG, "");
                Log.d(TAG, "Data stream ended");

            } catch (IOException e) {
                if (isConnected) {
                    Log.e(TAG, "✗ Receive error: " + e.getMessage());

                    uiHandler.post(() -> {
                        showToast("Connection lost");
                        disconnect();
                    });
                }
            }
        });

        receiveThread.start();
    }

    /**
     * Parse stock data and update UI
     */
    private void parseAndUpdateStock(String data) {
        try {
            String[] parts = data.split("\\|");

            if (parts.length >= 3) {
                String symbol = parts[0];
                double price = Double.parseDouble(parts[1]);
                String timestamp = parts[2];

                // Create or update stock
                Stock stock = new Stock(symbol, price, timestamp);

                // Update UI on main thread
                uiHandler.post(() -> {
                    adapter.updateStock(stock);
                    tvLastUpdate.setText("Last update: " + timestamp);
                });

                Log.d(TAG, "  " + symbol + " = $" +
                        String.format("%.2f", price));
            }

        } catch (Exception e) {
            Log.e(TAG, "Parse error: " + e.getMessage());
        }
    }

    /**
     * Disconnect from server
     */
    private void disconnect() {
        Log.d(TAG, "");
        Log.d(TAG, "═══ DISCONNECTING ═══");

        isConnected = false;

        new Thread(() -> {
            try {
                if (in != null) {
                    in.close();
                    Log.d(TAG, "✓ Input stream closed");
                }
                if (socket != null && !socket.isClosed()) {
                    socket.close();
                    Log.d(TAG, "✓ Socket closed");
                }

                Log.d(TAG, "✓ Disconnected");
                Log.d(TAG, "  Total updates received: " + updateCount);
                Log.d(TAG, "");

            } catch (IOException e) {
                Log.e(TAG, "Disconnect error: " + e.getMessage());
            }
        }).start();

        // Update UI
        updateStatus("Disconnected");
        btnConnect.setText("Connect");
        btnConnect.setEnabled(true);
        editServerIp.setEnabled(true);
        tvLastUpdate.setText("Last update: --:--:--");

        // Clear stock list
        adapter.clear();
    }

    /**
     * Update status text
     */
    private void updateStatus(String status) {
        tvStatus.setText("Status: " + status);
    }

    /**
     * Show toast message
     */
    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        Log.d(TAG, "Activity destroying");

        if (isConnected) {
            disconnect();
        }
    }
}