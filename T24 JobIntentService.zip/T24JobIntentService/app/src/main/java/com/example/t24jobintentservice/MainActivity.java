package com.example.t24jobintentservice;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    /**
     * Main Activity - Demonstrates enqueuing work to JobIntentService
     *
     * Shows:
     * 1. Simple logging task
     * 2. Data processing task
     * 3. Sync task with progress
     * 4. Multiple tasks in sequence
     * 5. Sequential work queue behavior
     */
    private static final String TAG = "MainActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        Log.d(TAG, "");
        Log.d(TAG, "╔════════════════════════════════════════╗");
        Log.d(TAG, "║   JOBINTENTSERVICE DEMO STARTED        ║");
        Log.d(TAG, "╚════════════════════════════════════════╝");
        Log.d(TAG, "");
        Log.d(TAG, "JobIntentService is a compatibility class that:");
        Log.d(TAG, "  • Works as IntentService on pre-Oreo");
        Log.d(TAG, "  • Works as JobScheduler on Oreo+");
        Log.d(TAG, "  • Runs work on background thread");
        Log.d(TAG, "  • Processes work sequentially");
        Log.d(TAG, "  • Deprecated in favor of WorkManager");
        Log.d(TAG, "");

        // Demonstrate different ways to enqueue work
        demonstrateWorkEnqueuing();
    }

    /**
     * Demonstrate various work enqueuing scenarios
     */
    private void demonstrateWorkEnqueuing() {
        Log.d(TAG, "═══ ENQUEUING WORK DEMONSTRATIONS ═══");
        Log.d(TAG, "");

        // 1. Simple logging task (immediate)
        enqueueLoggingTask();

        // 2. Data processing task (delayed 3 seconds)
        Handler handler = new Handler(Looper.getMainLooper());
        handler.postDelayed(() -> {
            enqueueDataProcessingTask();
        }, 3000);

        // 3. Sync task (delayed 6 seconds)
        handler.postDelayed(() -> {
            enqueueSyncTask();
        }, 6000);

        // 4. Multiple tasks (delayed 9 seconds)
        handler.postDelayed(() -> {
            enqueueMultipleTasks();
        }, 9000);

        Log.d(TAG, "");
        Log.d(TAG, "All work enqueuing scheduled");
        Log.d(TAG, "Watch logcat for sequential execution");
        Log.d(TAG, "Filter by: MyJobIntentService");
        Log.d(TAG, "");
    }

    /**
     * 1. Enqueue simple logging task
     */
    private void enqueueLoggingTask() {
        Log.d(TAG, "");
        Log.d(TAG, "┌─────────────────────────────────────┐");
        Log.d(TAG, "│   1. ENQUEUING LOGGING TASK         │");
        Log.d(TAG, "└─────────────────────────────────────┘");
        Log.d(TAG, "");

        // Create intent with action and extras
        Intent workIntent = new Intent();
        workIntent.setAction(MyJobIntentService.ACTION_LOG);
        workIntent.putExtra(MyJobIntentService.EXTRA_MESSAGE, "Test message from MainActivity");
        workIntent.putExtra(MyJobIntentService.EXTRA_COUNT, 5);

        Log.d(TAG, "Creating work intent:");
        Log.d(TAG, "  Action: " + MyJobIntentService.ACTION_LOG);
        Log.d(TAG, "  Extra - Message: Test message from MainActivity");
        Log.d(TAG, "  Extra - Count: 5");
        Log.d(TAG, "");

        // Enqueue work using static convenience method
        MyJobIntentService.enqueueWork(this, workIntent);

        Log.d(TAG, "✓ Logging task enqueued");
        Log.d(TAG, "");
    }

    /**
     * 2. Enqueue data processing task
     */
    private void enqueueDataProcessingTask() {
        Log.d(TAG, "");
        Log.d(TAG, "┌─────────────────────────────────────┐");
        Log.d(TAG, "│   2. ENQUEUING DATA PROCESSING      │");
        Log.d(TAG, "└─────────────────────────────────────┘");
        Log.d(TAG, "");

        Intent workIntent = new Intent();
        workIntent.setAction(MyJobIntentService.ACTION_PROCESS_DATA);
        workIntent.putExtra(MyJobIntentService.EXTRA_DATA,
                "{\"user_id\":123,\"name\":\"John\",\"items\":[1,2,3]}");

        Log.d(TAG, "Creating work intent:");
        Log.d(TAG, "  Action: " + MyJobIntentService.ACTION_PROCESS_DATA);
        Log.d(TAG, "  Extra - Data: JSON object with user info");
        Log.d(TAG, "");

        MyJobIntentService.enqueueWork(this, workIntent);

        Log.d(TAG, "✓ Data processing task enqueued");
        Log.d(TAG, "");
    }

    /**
     * 3. Enqueue sync task
     */
    private void enqueueSyncTask() {
        Log.d(TAG, "");
        Log.d(TAG, "┌─────────────────────────────────────┐");
        Log.d(TAG, "│   3. ENQUEUING SYNC TASK            │");
        Log.d(TAG, "└─────────────────────────────────────┘");
        Log.d(TAG, "");

        Intent workIntent = new Intent();
        workIntent.setAction(MyJobIntentService.ACTION_SYNC);
        workIntent.putExtra(MyJobIntentService.EXTRA_COUNT, 10);

        Log.d(TAG, "Creating work intent:");
        Log.d(TAG, "  Action: " + MyJobIntentService.ACTION_SYNC);
        Log.d(TAG, "  Extra - Count: 10 items to sync");
        Log.d(TAG, "");

        MyJobIntentService.enqueueWork(this, workIntent);

        Log.d(TAG, "✓ Sync task enqueued");
        Log.d(TAG, "");
    }

    /**
     * 4. Enqueue multiple tasks to demonstrate sequential processing
     */
    private void enqueueMultipleTasks() {
        Log.d(TAG, "");
        Log.d(TAG, "┌─────────────────────────────────────┐");
        Log.d(TAG, "│   4. ENQUEUING MULTIPLE TASKS       │");
        Log.d(TAG, "└─────────────────────────────────────┘");
        Log.d(TAG, "");
        Log.d(TAG, "Demonstrating sequential work queue:");
        Log.d(TAG, "  All tasks will execute ONE AT A TIME");
        Log.d(TAG, "  in the order they are enqueued");
        Log.d(TAG, "");

        // Enqueue 3 tasks quickly
        for (int i = 1; i <= 3; i++) {
            Intent workIntent = new Intent();
            workIntent.setAction(MyJobIntentService.ACTION_LOG);
            workIntent.putExtra(MyJobIntentService.EXTRA_MESSAGE, "Sequential task " + i);
            workIntent.putExtra(MyJobIntentService.EXTRA_COUNT, 3);

            Log.d(TAG, "Enqueuing task " + i + " of 3...");
            MyJobIntentService.enqueueWork(this, workIntent);
        }

        Log.d(TAG, "");
        Log.d(TAG, "✓ 3 tasks enqueued");
        Log.d(TAG, "  They will execute sequentially");
        Log.d(TAG, "  Watch logcat to see order");
        Log.d(TAG, "");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        Log.d(TAG, "");
        Log.d(TAG, "MainActivity destroyed");
        Log.d(TAG, "Note: JobIntentService continues running");
        Log.d(TAG, "      until work queue is empty");
        Log.d(TAG, "");
    }
}