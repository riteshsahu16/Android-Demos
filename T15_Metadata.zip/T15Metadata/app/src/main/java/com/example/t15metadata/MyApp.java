package com.example.t15metadata;

import android.app.Application;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;

/**
 * Custom Application class demonstrating how to read meta-data
 * from AndroidManifest.xml
 *
 * Meta-data is commonly used for:
 * - API keys (Google Maps, Firebase, Analytics, etc.)
 * - Configuration parameters
 * - Feature flags
 * - Version information
 */

public class MyApp extends Application {
    private static final String TAG = "MetadataDemo-App";

    // Store metadata for app-wide access
    private Bundle applicationMetadata;

    @Override
    public void onCreate() {
        super.onCreate();

        Log.d(TAG, "");
        Log.d(TAG, "╔═══════════════════════════════════════════╗");
        Log.d(TAG, "║   APPLICATION STARTED                     ║");
        Log.d(TAG, "║   Reading Metadata from Manifest          ║");
        Log.d(TAG, "╚═══════════════════════════════════════════╝");
        Log.d(TAG, "");

        // Read application-level metadata
        readApplicationMetadata();

        Log.d(TAG, "");
        Log.d(TAG, "Application initialization complete");
    }

    /**
     * Read metadata from <application> tag
     *
     * Method 1: Using getPackageManager() and getApplicationInfo()
     * This is the standard approach recommended by Android
     */
    private void readApplicationMetadata() {
        Log.d(TAG, "═══ READING APPLICATION METADATA ═══");
        Log.d(TAG, "");

        try {
            // Get PackageManager
            PackageManager pm = getPackageManager();
            String packageName = getPackageName();

            Log.d(TAG, "Package: " + packageName);
            Log.d(TAG, "");

            /*
             * GET_META_DATA flag is CRITICAL!
             * Without it, the metaData Bundle will be null
             */
            ApplicationInfo appInfo = pm.getApplicationInfo(
                    packageName,
                    PackageManager.GET_META_DATA
            );

            // Store for later use
            applicationMetadata = appInfo.metaData;

            if (applicationMetadata != null) {
                Log.d(TAG, "✓ Metadata bundle found");
                Log.d(TAG, "  Total entries: " + applicationMetadata.size());
                Log.d(TAG, "");

                // Read different types of metadata
                readStringMetadata();
                readIntegerMetadata();
                readBooleanMetadata();
                readFloatMetadata();
                readResourceMetadata();
                readSpecialCases();

            } else {
                Log.e(TAG, "✗ Metadata bundle is NULL");
                Log.e(TAG, "  Check if GET_META_DATA flag is used");
            }

        } catch (PackageManager.NameNotFoundException e) {
            Log.e(TAG, "✗ Package not found: " + e.getMessage());
        } catch (Exception e) {
            Log.e(TAG, "✗ Error reading metadata: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Read STRING metadata values
     */
    private void readStringMetadata() {
        Log.d(TAG, "┌─── STRING Metadata ─────────────────┐");

        // Example: API key
        String apiKey = applicationMetadata.getString("app.config.api_key");
        Log.d(TAG, "│ API Key: " + (apiKey != null ? apiKey : "null"));

        // Example: Server configuration
        String serverId = applicationMetadata.getString("app.config.server_id");
        Log.d(TAG, "│ Server ID: " + (serverId != null ? serverId : "null"));

        Log.d(TAG, "└─────────────────────────────────────┘");
        Log.d(TAG, "");
    }

    /**
     * Read INTEGER metadata values
     */
    private void readIntegerMetadata() {
        Log.d(TAG, "┌─── INTEGER Metadata ────────────────┐");

        // Method 1: getInt() - returns 0 if not found
        int maxItems = applicationMetadata.getInt("app.config.max_items");
        Log.d(TAG, "│ Max Items: " + maxItems);

        // Method 2: getInt() with default value
        int timeout = applicationMetadata.getInt("app.config.timeout", 30);
        Log.d(TAG, "│ Timeout (with default): " + timeout + " sec");

        // Check if key exists
        boolean hasKey = applicationMetadata.containsKey("app.config.max_items");
        Log.d(TAG, "│ Has 'max_items' key: " + hasKey);

        Log.d(TAG, "└─────────────────────────────────────┘");
        Log.d(TAG, "");
    }

    /**
     * Read BOOLEAN metadata values
     */
    private void readBooleanMetadata() {
        Log.d(TAG, "┌─── BOOLEAN Metadata ────────────────┐");

        // getBoolean() - returns false if not found
        boolean debugMode = applicationMetadata.getBoolean("app.config.debug_mode");
        Log.d(TAG, "│ Debug Mode: " + debugMode);

        // getBoolean() with default value
        boolean enableCrashReporting = applicationMetadata.getBoolean(
                "app.config.crash_reporting",
                true  // default
        );
        Log.d(TAG, "│ Crash Reporting (with default): " + enableCrashReporting);

        Log.d(TAG, "└─────────────────────────────────────┘");
        Log.d(TAG, "");
    }

    /**
     * Read FLOAT metadata values
     */
    private void readFloatMetadata() {
        Log.d(TAG, "┌─── FLOAT Metadata ──────────────────┐");

        // getFloat() - returns 0.0 if not found
        float cacheSizeMb = applicationMetadata.getFloat("app.config.cache_size_mb");
        Log.d(TAG, "│ Cache Size: " + cacheSizeMb + " MB");

        // getFloat() with default value
        float refreshRate = applicationMetadata.getFloat(
                "app.config.refresh_rate",
                60.0f  // default
        );
        Log.d(TAG, "│ Refresh Rate (with default): " + refreshRate + " Hz");

        Log.d(TAG, "└─────────────────────────────────────┘");
        Log.d(TAG, "");
    }

    /**
     * Read RESOURCE metadata (references to strings, integers, colors, etc.)
     *
     * When using android:resource instead of android:value,
     * the metadata stores the resource ID (integer)
     */
    private void readResourceMetadata() {
        Log.d(TAG, "┌─── RESOURCE Metadata ───────────────┐");

        // String resource
        int appNameResId = applicationMetadata.getInt("app.config.app_name");
        if (appNameResId != 0) {
            String appName = getString(appNameResId);
            Log.d(TAG, "│ App Name (resource): " + appName);
            Log.d(TAG, "│   Resource ID: " + appNameResId);
        }

        // Integer resource
        int versionCodeResId = applicationMetadata.getInt("app.config.version_code");
        if (versionCodeResId != 0) {
            int versionCode = getResources().getInteger(versionCodeResId);
            Log.d(TAG, "│ Version Code (resource): " + versionCode);
            Log.d(TAG, "│   Resource ID: " + versionCodeResId);
        }

        // Color resource
        int colorResId = applicationMetadata.getInt("app.config.primary_color");
        if (colorResId != 0) {
            int color = getResources().getColor(colorResId, null);
            String colorHex = String.format("#%06X", (0xFFFFFF & color));
            Log.d(TAG, "│ Primary Color (resource): " + colorHex);
            Log.d(TAG, "│   Resource ID: " + colorResId);
        }

        Log.d(TAG, "└─────────────────────────────────────┘");
        Log.d(TAG, "");
    }

    /**
     * Handle special cases and edge cases
     */
    private void readSpecialCases() {
        Log.d(TAG, "┌─── SPECIAL CASES ───────────────────┐");

        /*
         * ISSUE: Large numeric strings
         *
         * Problem: Android auto-parses numeric strings as integers
         * Example: "1234567890123456789" gets parsed as int and may overflow
         *
         * Solutions:
         * 1. Prefix with escaped space: android:value="\ 123456789"
         * 2. Use resource reference: android:resource="@string/my_number"
         */

        // Solution 1: Escaped space prefix (space is removed in result)
        String accountId = applicationMetadata.getString("app.config.account_id");
        Log.d(TAG, "│ Account ID (escaped space): " + accountId);
        if (accountId != null) {
            Log.d(TAG, "│   Length: " + accountId.length() + " chars");
        }

        // Solution 2: Resource reference
        int serverIdResId = applicationMetadata.getInt("app.config.server_id");
        if (serverIdResId != 0) {
            String serverId = getString(serverIdResId);
            Log.d(TAG, "│ Server ID (resource): " + serverId);
            Log.d(TAG, "│   Length: " + serverId.length() + " chars");
        }

        /*
         * Checking for missing keys
         */
        boolean hasMissingKey = applicationMetadata.containsKey("app.config.missing_key");
        Log.d(TAG, "│ Has missing key: " + hasMissingKey);

        /*
         * Get raw Object type (advanced usage)
         * Useful to determine actual data type
         */
        Object rawValue = applicationMetadata.get("app.config.max_items");
        if (rawValue != null) {
            Log.d(TAG, "│ Raw value type: " + rawValue.getClass().getSimpleName());
            Log.d(TAG, "│ Raw value: " + rawValue);
        }

        Log.d(TAG, "└─────────────────────────────────────┘");
        Log.d(TAG, "");
    }

    /**
     * Public method to access metadata from anywhere in the app
     *
     * Usage:
     *   MyApp app = (MyApp) getApplication();
     *   String apiKey = app.getMetadataString("app.config.api_key");
     */
    public String getMetadataString(String key) {
        if (applicationMetadata != null) {
            return applicationMetadata.getString(key);
        }
        return null;
    }

    public int getMetadataInt(String key, int defaultValue) {
        if (applicationMetadata != null) {
            return applicationMetadata.getInt(key, defaultValue);
        }
        return defaultValue;
    }

    public boolean getMetadataBoolean(String key, boolean defaultValue) {
        if (applicationMetadata != null) {
            return applicationMetadata.getBoolean(key, defaultValue);
        }
        return defaultValue;
    }

    public float getMetadataFloat(String key, float defaultValue) {
        if (applicationMetadata != null) {
            return applicationMetadata.getFloat(key, defaultValue);
        }
        return defaultValue;
    }
}
