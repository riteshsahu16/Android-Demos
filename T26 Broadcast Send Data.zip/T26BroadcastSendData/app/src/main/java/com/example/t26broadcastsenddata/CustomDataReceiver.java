package com.example.t26broadcastsenddata;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

/**
 * Custom BroadcastReceiver that receives data from broadcast Intent
 *
 * Demonstrates extracting different data types:
 * - String
 * - int
 * - boolean
 * - double
 * - long
 * - Bundle
 * - Parcelable arrays
 */
public class CustomDataReceiver extends BroadcastReceiver {
    private static final String TAG = "CustomDataReceiver";

    /**
     * onReceive() - Called when broadcast is received
     *
     * IMPORTANT:
     * - Runs on MAIN THREAD - keep it fast!
     * - Don't perform long operations here
     * - Extract data and process quickly
     */
    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d(TAG, "");
        Log.d(TAG, "╔════════════════════════════════════════╗");
        Log.d(TAG, "║   BROADCAST RECEIVED                   ║");
        Log.d(TAG, "╚════════════════════════════════════════╝");
        Log.d(TAG, "");

        // Get the action
        String action = intent.getAction();
        Log.d(TAG, "Action: " + action);
        Log.d(TAG, "");

        // Extract data based on action
        if ("com.example.ACTION_USER_DATA".equals(action)) {
            handleUserData(context, intent);

        } else if ("com.example.ACTION_NOTIFICATION".equals(action)) {
            handleNotification(context, intent);

        } else if ("com.example.ACTION_COMPLEX_DATA".equals(action)) {
            handleComplexData(context, intent);

        } else {
            Log.w(TAG, "Unknown action received: " + action);
        }

        Log.d(TAG, "");
    }

    /**
     * Handle user data broadcast
     * Demonstrates extracting String, int, boolean data
     */
    private void handleUserData(Context context, Intent intent) {
        Log.d(TAG, "┌─────────────────────────────────────┐");
        Log.d(TAG, "│   USER DATA BROADCAST               │");
        Log.d(TAG, "└─────────────────────────────────────┘");
        Log.d(TAG, "");

        // Extract String data
        String name = intent.getStringExtra("user_name");
        String email = intent.getStringExtra("user_email");

        // Extract int data
        int age = intent.getIntExtra("user_age", -1);  // -1 is default if not found

        // Extract boolean data
        boolean isPremium = intent.getBooleanExtra("is_premium", false);

        // Extract long data
        long userId = intent.getLongExtra("user_id", 0L);

        Log.d(TAG, "Extracted Data:");
        Log.d(TAG, "  Name: " + name);
        Log.d(TAG, "  Email: " + email);
        Log.d(TAG, "  Age: " + age);
        Log.d(TAG, "  User ID: " + userId);
        Log.d(TAG, "  Premium: " + isPremium);
        Log.d(TAG, "");

        // Validate data
        if (name == null || name.isEmpty()) {
            Log.w(TAG, "⚠ Warning: User name is empty");
        } else {
            Log.d(TAG, "✓ Data validation passed");
        }

        // Display data in Toast
        String message = String.format(
                "User: %s\nAge: %d\nPremium: %s",
                name != null ? name : "Unknown",
                age,
                isPremium ? "Yes" : "No"
        );

        Toast.makeText(context, message, Toast.LENGTH_LONG).show();
        Log.d(TAG, "✓ Toast displayed");
    }

    /**
     * Handle notification broadcast
     * Demonstrates extracting String and checking for null
     */
    private void handleNotification(Context context, Intent intent) {
        Log.d(TAG, "┌─────────────────────────────────────┐");
        Log.d(TAG, "│   NOTIFICATION BROADCAST            │");
        Log.d(TAG, "└─────────────────────────────────────┘");
        Log.d(TAG, "");

        // Extract notification data
        String title = intent.getStringExtra("notification_title");
        String message = intent.getStringExtra("notification_message");
        int priority = intent.getIntExtra("notification_priority", 0);

        Log.d(TAG, "Notification Details:");
        Log.d(TAG, "  Title: " + title);
        Log.d(TAG, "  Message: " + message);
        Log.d(TAG, "  Priority: " + priority);
        Log.d(TAG, "");

        // Check for null values
        if (title == null) {
            Log.w(TAG, "⚠ Title is null, using default");
            title = "Notification";
        }

        if (message == null) {
            Log.w(TAG, "⚠ Message is null, using default");
            message = "No message";
        }

        // Display notification-style toast
        String displayText = "📢 " + title + "\n" + message;
        Toast.makeText(context, displayText, Toast.LENGTH_LONG).show();

        Log.d(TAG, "✓ Notification processed and displayed");
    }

    /**
     * Handle complex data broadcast
     * Demonstrates extracting Bundle, double, and checking extras
     */
    private void handleComplexData(Context context, Intent intent) {
        Log.d(TAG, "┌─────────────────────────────────────┐");
        Log.d(TAG, "│   COMPLEX DATA BROADCAST            │");
        Log.d(TAG, "└─────────────────────────────────────┘");
        Log.d(TAG, "");

        // Extract all extras as Bundle
        Bundle extras = intent.getExtras();

        if (extras != null) {
            Log.d(TAG, "Bundle contains " + extras.size() + " items:");

            // Iterate through all extras
            for (String key : extras.keySet()) {
                Object value = extras.get(key);
                String valueType = value != null ? value.getClass().getSimpleName() : "null";
                Log.d(TAG, "  " + key + " = " + value + " (" + valueType + ")");
            }
            Log.d(TAG, "");

            // Extract specific data types
            double price = intent.getDoubleExtra("price", 0.0);
            float rating = intent.getFloatExtra("rating", 0.0f);
            String[] tags = intent.getStringArrayExtra("tags");

            Log.d(TAG, "Specific Extractions:");
            Log.d(TAG, "  Price: $" + String.format("%.2f", price));
            Log.d(TAG, "  Rating: " + rating + " stars");

            if (tags != null && tags.length > 0) {
                Log.d(TAG, "  Tags (" + tags.length + "):");
                for (String tag : tags) {
                    Log.d(TAG, "    - " + tag);
                }
            }
            Log.d(TAG, "");

            // Create summary for Toast
            String summary = String.format(
                    "Price: $%.2f\nRating: %.1f⭐\nTags: %d",
                    price,
                    rating,
                    tags != null ? tags.length : 0
            );

            Toast.makeText(context, summary, Toast.LENGTH_LONG).show();

        } else {
            Log.w(TAG, "⚠ No extras found in Intent");
        }
    }
}
