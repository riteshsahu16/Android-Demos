package com.example.t04activityargspass;

import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Second extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_second);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        TextView textView = findViewById(R.id.textView);

        // fetch arrays from intent
        String[] hobbies = getIntent().getStringArrayExtra("hobbies");
        int[] favNums = getIntent().getIntArrayExtra("favnumbers");

        // Display
        StringBuilder builder = new StringBuilder();
        builder.append("Hobbies:\n");
        if(hobbies != null){
            for(String hobby: hobbies){
                builder.append("- ").append(hobby).append("\n");
            }
        }
        builder.append("\nFavourite Numbers:");
        if(favNums != null){
            for(int num : favNums){
                builder.append(num).append(" ");
            }
        }
        textView.setText(builder.toString());
    }
}