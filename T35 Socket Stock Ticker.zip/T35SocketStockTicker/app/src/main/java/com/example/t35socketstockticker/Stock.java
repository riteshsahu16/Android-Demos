package com.example.t35socketstockticker;

public class Stock {
        private String symbol;
        private double price;
        private double previousPrice;
        private String timestamp;

        public Stock(String symbol, double price, String timestamp) {
            this.symbol = symbol;
            this.price = price;
            this.previousPrice = price;
            this.timestamp = timestamp;
        }

        public String getSymbol() {
            return symbol;
        }

        public double getPrice() {
            return price;
        }

        public void setPrice(double price) {
            this.previousPrice = this.price;
            this.price = price;
        }

        public double getPreviousPrice() {
            return previousPrice;
        }

        public boolean isPriceUp() {
            return price > previousPrice;
        }

        public boolean isPriceDown() {
            return price < previousPrice;
        }

        public String getTimestamp() {
            return timestamp;
        }

        public void setTimestamp(String timestamp) {
            this.timestamp = timestamp;
        }
    }


