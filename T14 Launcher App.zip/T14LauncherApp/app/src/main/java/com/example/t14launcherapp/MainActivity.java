package com.example.t14launcherapp;

import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.List;

/**
 * Launcher App - Demonstrates launching activities from other apps
 *
 * This shows THREE methods to launch external activities:
 * 1. Explicit Intent (knows exact component)
 * 2. Implicit Intent (uses intent filter matching)
 * 3. Custom URI scheme
 */
public class MainActivity extends AppCompatActivity {
    private static final String TAG = "LauncherApp";

    // Target app details
    private static final String TARGET_PACKAGE = "com.example.t14launchfromanotherapp";
    private static final String TARGET_ACTIVITY = "com.example.t14launchfromanotherapp.Exported";
    private static final String CUSTOM_ACTION = "com.example.t14launchfromanotherapp.ACTION_CUSTOM";
    private static final String CUSTOM_SCHEME = "targetapp://open";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Log.d(TAG, "");
        Log.d(TAG, "╔═══════════════════════════════════════════╗");
        Log.d(TAG, "║     LAUNCHER APP STARTED                  ║");
        Log.d(TAG, "║  Demonstrating Cross-App Communication    ║");
        Log.d(TAG, "╚═══════════════════════════════════════════╝");
        Log.d(TAG, "");

        // Check if target app is installed
        if (isTargetAppInstalled()) {
            Log.d(TAG, "✓ Target app is installed");
            Log.d(TAG, "  Package: " + TARGET_PACKAGE);
            Log.d(TAG, "");

            // Demonstrate different launch methods
            demonstrateAllLaunchMethods();

        } else {
            Log.e(TAG, "✗ Target app is NOT installed");
            Log.e(TAG, "  Please install Target App first");
            Log.e(TAG, "  Package: " + TARGET_PACKAGE);
        }
    }

    /**
     * Demonstrate all three methods of launching external activities
     */
    private void demonstrateAllLaunchMethods() {
        Log.d(TAG, "=== DEMONSTRATION: 3 Ways to Launch External Activity ===");
        Log.d(TAG, "");

        // Wait between launches to see clear separation in logs
        try {
            // Method 1: Explicit Intent
            launchWithExplicitIntent();
            Thread.sleep(2000);

            // Method 2: Implicit Intent
            launchWithImplicitIntent();
            Thread.sleep(2000);

            // Method 3: Custom URI
            launchWithCustomUri();
            Thread.sleep(2000);

            // Method 4: Custom Action
            launchWithCustomAction();

        } catch (InterruptedException e) {
            Log.e(TAG, "Sleep interrupted: " + e.getMessage());
        }
    }
    /**
     * METHOD 1: Launch with EXPLICIT Intent
     *
     * Pros:
     * - Direct, fast, no ambiguity
     * - You know exactly which component will be launched
     *
     * Cons:
     * - Requires knowing exact package and class names
     * - Tightly couples your app to the target app
     * - If target app changes class name, this breaks
     */
    private void launchWithExplicitIntent() {
        Log.d(TAG, "");
        Log.d(TAG, "┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓");
        Log.d(TAG, "┃ METHOD 1: EXPLICIT INTENT            ┃");
        Log.d(TAG, "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛");
        Log.d(TAG, "");
        Log.d(TAG, "Creating explicit intent with ComponentName");
        Log.d(TAG, "Target Package: " + TARGET_PACKAGE);
        Log.d(TAG, "Target Class: " + TARGET_ACTIVITY);

        try {
            // Create intent with explicit component name
            Intent intent = new Intent();
            ComponentName component = new ComponentName(TARGET_PACKAGE, TARGET_ACTIVITY);
            intent.setComponent(component);

            // Add extra data
            intent.putExtra("message", "Hello from Launcher App!");
            intent.putExtra("launch_method", "EXPLICIT_INTENT");
            intent.putExtra("timestamp", System.currentTimeMillis());

            Log.d(TAG, "");
            Log.d(TAG, "Intent created:");
            Log.d(TAG, "  Component: " + component.flattenToShortString());
            Log.d(TAG, "  Extras: message, launch_method, timestamp");
            Log.d(TAG, "");
            Log.d(TAG, "🚀 Launching activity...");

            startActivity(intent);

            Log.d(TAG, "✓ Activity launched successfully");
            Log.d(TAG, "");

        } catch (Exception e) {
            Log.e(TAG, "✗ Failed to launch activity");
            Log.e(TAG, "  Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * METHOD 2: Launch with IMPLICIT Intent
     *
     * Pros:
     * - Flexible, works with any app that handles the action
     * - Loose coupling between apps
     * - User can choose which app to use (if multiple match)
     *
     * Cons:
     * - Requires intent filter on target side
     * - Might match multiple apps (shows chooser)
     * - Less predictable which app handles it
     */
    private void launchWithImplicitIntent() {
        Log.d(TAG, "");
        Log.d(TAG, "┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓");
        Log.d(TAG, "┃ METHOD 2: IMPLICIT INTENT            ┃");
        Log.d(TAG, "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛");
        Log.d(TAG, "");
        Log.d(TAG, "Creating implicit intent with ACTION_VIEW");
        Log.d(TAG, "Let Android find matching activities");

        try {
            // Create implicit intent
            Intent intent = new Intent(Intent.ACTION_VIEW);

            // Set package to target specific app (optional)
            // Without this, ANY app matching the intent could handle it
            intent.setPackage(TARGET_PACKAGE);

            // Add extra data
            intent.putExtra("message", "Implicit intent from Launcher App");
            intent.putExtra("launch_method", "IMPLICIT_INTENT");

            Log.d(TAG, "");
            Log.d(TAG, "Intent created:");
            Log.d(TAG, "  Action: " + Intent.ACTION_VIEW);
            Log.d(TAG, "  Package: " + TARGET_PACKAGE + " (filtered)");
            Log.d(TAG, "");

            // Check if any activity can handle this intent
            PackageManager pm = getPackageManager();
            List<ResolveInfo> activities = pm.queryIntentActivities(intent, 0);

            if (!activities.isEmpty()) {
                Log.d(TAG, "Found " + activities.size() + " matching activity(ies):");
                for (ResolveInfo info : activities) {
                    Log.d(TAG, "  - " + info.activityInfo.name);
                }
                Log.d(TAG, "");
                Log.d(TAG, "🚀 Launching activity...");

                startActivity(intent);

                Log.d(TAG, "✓ Activity launched successfully");
            } else {
                Log.w(TAG, "✗ No activities found to handle this intent");
            }
            Log.d(TAG, "");

        } catch (Exception e) {
            Log.e(TAG, "✗ Failed to launch activity");
            Log.e(TAG, "  Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * METHOD 3: Launch with CUSTOM URI Scheme
     *
     * Pros:
     * - Works like web links (deep linking)
     * - Can be triggered from browser, email, SMS, etc.
     * - User-friendly format
     *
     * Cons:
     * - Requires custom scheme registration
     * - Can conflict with other apps using same scheme
     * - Limited to URL-like data structure
     */
    private void launchWithCustomUri() {
        Log.d(TAG, "");
        Log.d(TAG, "┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓");
        Log.d(TAG, "┃ METHOD 3: CUSTOM URI SCHEME          ┃");
        Log.d(TAG, "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛");
        Log.d(TAG, "");
        Log.d(TAG, "Creating intent with custom URI scheme");
        Log.d(TAG, "Similar to deep links (targetapp://)");

        try {
            // Create URI with custom scheme
            String uriString = CUSTOM_SCHEME + "?param1=value1&param2=value2&source=launcher";
            Uri uri = Uri.parse(uriString);

            Log.d(TAG, "");
            Log.d(TAG, "Custom URI: " + uriString);
            Log.d(TAG, "  Scheme: " + uri.getScheme());
            Log.d(TAG, "  Path: " + uri.getPath());
            Log.d(TAG, "  Query: " + uri.getQuery());
            Log.d(TAG, "");

            // Create intent with URI
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            intent.putExtra("launch_method", "CUSTOM_URI");

            // Check if any activity can handle this URI scheme
            PackageManager pm = getPackageManager();
            List<ResolveInfo> activities = pm.queryIntentActivities(intent, 0);

            if (!activities.isEmpty()) {
                Log.d(TAG, "Found " + activities.size() + " app(s) handling this URI:");
                for (ResolveInfo info : activities) {
                    Log.d(TAG, "  - " + info.activityInfo.packageName);
                }
                Log.d(TAG, "");
                Log.d(TAG, "🚀 Launching via URI...");

                startActivity(intent);

                Log.d(TAG, "✓ Activity launched successfully");
            } else {
                Log.w(TAG, "✗ No apps found to handle URI: " + uri.getScheme() + "://");
            }
            Log.d(TAG, "");

        } catch (Exception e) {
            Log.e(TAG, "✗ Failed to launch activity");
            Log.e(TAG, "  Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * METHOD 4: Launch with CUSTOM ACTION
     *
     * Demonstrates using app-specific custom actions
     */
    private void launchWithCustomAction() {
        Log.d(TAG, "");
        Log.d(TAG, "┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓");
        Log.d(TAG, "┃ METHOD 4: CUSTOM ACTION              ┃");
        Log.d(TAG, "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛");
        Log.d(TAG, "");
        Log.d(TAG, "Creating intent with custom action string");
        Log.d(TAG, "Action: " + CUSTOM_ACTION);

        try {
            Intent intent = new Intent(CUSTOM_ACTION);
            intent.setPackage(TARGET_PACKAGE);

            // Add custom parameters
            intent.putExtra("param1", "Custom value 1");
            intent.putExtra("param2", "Custom value 2");
            intent.putExtra("number", 42);
            intent.putExtra("launch_method", "CUSTOM_ACTION");

            Log.d(TAG, "");
            Log.d(TAG, "Intent extras:");
            Log.d(TAG, "  param1: Custom value 1");
            Log.d(TAG, "  param2: Custom value 2");
            Log.d(TAG, "  number: 42");
            Log.d(TAG, "");
            Log.d(TAG, "🚀 Launching with custom action...");

            startActivity(intent);

            Log.d(TAG, "✓ Activity launched successfully");
            Log.d(TAG, "");

        } catch (Exception e) {
            Log.e(TAG, "✗ Failed to launch activity");
            Log.e(TAG, "  Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Check if target app is installed
     */
    private boolean isTargetAppInstalled() {
        try {
            getPackageManager().getPackageInfo(TARGET_PACKAGE, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "");
        Log.d(TAG, "Launcher App destroyed");
        Log.d(TAG, "");
    }

}