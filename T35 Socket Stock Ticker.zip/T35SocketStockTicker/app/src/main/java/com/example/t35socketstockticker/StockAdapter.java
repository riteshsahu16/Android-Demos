package com.example.t35socketstockticker;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

/**
 * RecyclerView Adapter for stock list
 */
public class StockAdapter extends RecyclerView.Adapter<StockAdapter.StockViewHolder> {
    private List<Stock> stocks = new ArrayList<>();

    @NonNull
    @Override
    public StockViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_stock, parent, false);
        return new StockViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull StockViewHolder holder, int position) {
        Stock stock = stocks.get(position);
        holder.bind(stock);
    }

    @Override
    public int getItemCount() {
        return stocks.size();
    }

    /**
     * Update stock data
     */
    public void updateStock(Stock updatedStock) {
        for (int i = 0; i < stocks.size(); i++) {
            if (stocks.get(i).getSymbol().equals(updatedStock.getSymbol())) {
                stocks.set(i, updatedStock);
                notifyItemChanged(i);
                return;
            }
        }

        // If stock doesn't exist, add it
        stocks.add(updatedStock);
        notifyItemInserted(stocks.size() - 1);
    }

    /**
     * Clear all stocks
     */
    public void clear() {
        stocks.clear();
        notifyDataSetChanged();
    }

    /**
     * ViewHolder for stock items
     */
    static class StockViewHolder extends RecyclerView.ViewHolder {
        private TextView tvSymbol;
        private TextView tvPrice;
        private TextView tvChange;

        public StockViewHolder(@NonNull View itemView) {
            super(itemView);
            tvSymbol = itemView.findViewById(R.id.tvSymbol);
            tvPrice = itemView.findViewById(R.id.tvPrice);
            tvChange = itemView.findViewById(R.id.tvChange);
        }

        public void bind(Stock stock) {
            tvSymbol.setText(stock.getSymbol());
            tvPrice.setText(String.format("$%.2f", stock.getPrice()));

            // Show price change indicator
            if (stock.isPriceUp()) {
                tvChange.setText("↑");
                tvChange.setTextColor(Color.parseColor("#4CAF50")); // Green
                tvPrice.setTextColor(Color.parseColor("#4CAF50"));
            } else if (stock.isPriceDown()) {
                tvChange.setText("↓");
                tvChange.setTextColor(Color.parseColor("#F44336")); // Red
                tvPrice.setTextColor(Color.parseColor("#F44336"));
            } else {
                tvChange.setText("—");
                tvChange.setTextColor(Color.parseColor("#9E9E9E")); // Gray
                tvPrice.setTextColor(Color.parseColor("#000000"));
            }
        }
    }
}
