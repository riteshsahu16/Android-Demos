package com.example.t12customappclass;

import android.app.Application;
import android.content.res.Configuration;
import android.util.Log;

/**
 * Custom Application Class
 *
 * Purpose: Runs BEFORE any Activity, Service, or other component is created
 * Use cases:
 *  - Initialize libraries/SDKs (Firebase, Crashlytics, Analytics, etc.)
 *  - Set up dependency injection (Dagger/Hilt, Koin)
 *  - Configure global app settings
 *  - Create shared singletons (Database, Network client, etc.)
 *  - Register ActivityLifecycleCallbacks for monitoring
 */

public class MyApp extends Application {
    private static final String TAG = "MyApp";

    // Static reference to access Application context from anywhere
    // Note: Use sparingly - dependency injection is preferred
    private static MyApp instance;

    /**
     * Constructor - Called before onCreate()
     * Usually don't need to override this
     */
    public MyApp() {
        super();
        Log.d(TAG, "Constructor called - Application object created");
    }

    /**
     * onCreate() - Main initialization point
     * Called once when the application is starting
     * Runs on the main thread - keep initialization fast!
     */
    @Override
    public void onCreate() {
        super.onCreate();

        Log.d(TAG, "=== APPLICATION STARTED ===");
        Log.d(TAG, "onCreate() called - Before any Activity/Service/Receiver");

        // Store static instance
        instance = this;

        // Example initializations
        initializeLibraries();
        setupGlobalSettings();
        registerLifecycleCallbacks();

        Log.d(TAG, "Application initialization complete");
    }
    /**
     * Called when the overall system is running low on memory
     * Use this to release caches or other non-critical resources
     */
    @Override
    public void onLowMemory() {
        super.onLowMemory();
        Log.w(TAG, "onLowMemory() - System is low on memory!");
        Log.w(TAG, "Consider releasing caches and non-essential resources");
    }

    /**
     * Called when system needs to trim memory
     * More granular than onLowMemory()
     */
    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        Log.w(TAG, "onTrimMemory() - Level: " + getTrimMemoryLevelName(level));

        // Handle different memory pressure levels
        switch (level) {
            case TRIM_MEMORY_RUNNING_MODERATE:
                Log.w(TAG, "Device is running moderately low on memory");
                break;
            case TRIM_MEMORY_RUNNING_LOW:
                Log.w(TAG, "Device is running low on memory");
                break;
            case TRIM_MEMORY_RUNNING_CRITICAL:
                Log.w(TAG, "Device is running critically low on memory");
                break;
            case TRIM_MEMORY_UI_HIDDEN:
                Log.i(TAG, "App UI is hidden - good time to release UI resources");
                break;
        }
    }

    /**
     * Called when device configuration changes (rotation, language, etc.)
     * Note: Usually handled in Activity, but available here for global changes
     */
    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        Log.i(TAG, "onConfigurationChanged() - Device configuration changed");

        // Check orientation change
        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            Log.i(TAG, "Device is now in LANDSCAPE mode");
        } else if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT) {
            Log.i(TAG, "Device is now in PORTRAIT mode");
        }
    }

    /**
     * Called when application is terminating
     * Note: This is NOT guaranteed to be called!
     * Never rely on this for critical cleanup - Android may kill process without calling it
     */
    @Override
    public void onTerminate() {
        super.onTerminate();
        Log.d(TAG, "onTerminate() - Application is terminating");
        Log.d(TAG, "WARNING: This is NOT called on real devices, only emulator!");
    }

    // ========== Helper Methods ==========

    /**
     * Initialize third-party libraries
     * Examples: Firebase, Crashlytics, Analytics, Timber, etc.
     */
    private void initializeLibraries() {
        Log.d(TAG, "Initializing libraries...");

        // Example: Initialize crash reporting
        // FirebaseApp.initializeApp(this);
        // Crashlytics.init(this);

        // Example: Initialize analytics
        // Analytics.initialize(this);

        // Example: Initialize logging library
        // Timber.plant(new Timber.DebugTree());

        Log.d(TAG, "Libraries initialized");
    }

    /**
     * Configure global app settings
     */
    private void setupGlobalSettings() {
        Log.d(TAG, "Setting up global configurations...");

        // Example: Configure strict mode for development
        // if (BuildConfig.DEBUG) {
        //     StrictMode.enableDefaults();
        // }

        // Example: Set default timezone
        // TimeZone.setDefault(TimeZone.getTimeZone("UTC"));

        Log.d(TAG, "Global settings configured");
    }

    /**
     * Register callbacks to monitor Activity lifecycle
     * Useful for tracking app foreground/background state
     */
    private void registerLifecycleCallbacks() {
        Log.d(TAG, "Registering activity lifecycle callbacks...");

        registerActivityLifecycleCallbacks(new ActivityLifecycleCallbacks() {
            @Override
            public void onActivityCreated(android.app.Activity activity,
                                          android.os.Bundle savedInstanceState) {
                Log.i(TAG, "Activity Created: " + activity.getClass().getSimpleName());
            }

            @Override
            public void onActivityStarted(android.app.Activity activity) {
                Log.i(TAG, "Activity Started: " + activity.getClass().getSimpleName());
            }

            @Override
            public void onActivityResumed(android.app.Activity activity) {
                Log.i(TAG, "Activity Resumed: " + activity.getClass().getSimpleName());
            }

            @Override
            public void onActivityPaused(android.app.Activity activity) {
                Log.i(TAG, "Activity Paused: " + activity.getClass().getSimpleName());
            }

            @Override
            public void onActivityStopped(android.app.Activity activity) {
                Log.i(TAG, "Activity Stopped: " + activity.getClass().getSimpleName());
            }

            @Override
            public void onActivitySaveInstanceState(android.app.Activity activity,
                                                    android.os.Bundle outState) {
                Log.i(TAG, "Activity Saving State: " + activity.getClass().getSimpleName());
            }

            @Override
            public void onActivityDestroyed(android.app.Activity activity) {
                Log.i(TAG, "Activity Destroyed: " + activity.getClass().getSimpleName());
            }
        });

        Log.d(TAG, "Lifecycle callbacks registered");
    }

    /**
     * Convert memory trim level constant to readable name
     */
    private String getTrimMemoryLevelName(int level) {
        switch (level) {
            case TRIM_MEMORY_COMPLETE: return "TRIM_MEMORY_COMPLETE";
            case TRIM_MEMORY_MODERATE: return "TRIM_MEMORY_MODERATE";
            case TRIM_MEMORY_BACKGROUND: return "TRIM_MEMORY_BACKGROUND";
            case TRIM_MEMORY_UI_HIDDEN: return "TRIM_MEMORY_UI_HIDDEN";
            case TRIM_MEMORY_RUNNING_CRITICAL: return "TRIM_MEMORY_RUNNING_CRITICAL";
            case TRIM_MEMORY_RUNNING_LOW: return "TRIM_MEMORY_RUNNING_LOW";
            case TRIM_MEMORY_RUNNING_MODERATE: return "TRIM_MEMORY_RUNNING_MODERATE";
            default: return "UNKNOWN(" + level + ")";
        }
    }

    /**
     * Static method to get Application instance
     * Use case: Access Application context from non-Activity classes
     * Warning: Prefer dependency injection over this pattern
     */
    public static MyApp getInstance() {
        return instance;
    }

    /**
     * Example of a globally accessible utility method
     */
    public static String getAppVersion() {
        try {
            String packageName = instance.getPackageName();
            String version = instance.getPackageManager()
                    .getPackageInfo(packageName, 0).versionName;
            return version;
        } catch (Exception e) {
            return "Unknown";
        }
    }
}
