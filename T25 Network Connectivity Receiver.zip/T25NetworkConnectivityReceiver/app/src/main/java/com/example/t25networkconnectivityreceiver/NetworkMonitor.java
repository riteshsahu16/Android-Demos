package com.example.t25networkconnectivityreceiver;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.os.Build;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;

/**
 * Network Monitor using ConnectivityManager.NetworkCallback
 *
 * MODERN APPROACH (Recommended for Android N+ / API 24+)
 *
 * Advantages over BroadcastReceiver:
 * - Works reliably on all Android versions
 * - Better battery life (no constant broadcasts)
 * - More detailed network information
 * - Can request specific network types
 * - Not deprecated
 *
 * This is the RECOMMENDED approach for production apps
 */
public class NetworkMonitor {
    private static final String TAG = "NetworkMonitor";

    private Context context;
    private ConnectivityManager connectivityManager;
    private ConnectivityManager.NetworkCallback networkCallback;
    private boolean isRegistered = false;

    public NetworkMonitor(Context context) {
        this.context = context;
        this.connectivityManager = (ConnectivityManager)
                context.getSystemService(Context.CONNECTIVITY_SERVICE);
    }

    /**
     * Start monitoring network changes
     */
    public void startMonitoring() {
        if (isRegistered) {
            Log.w(TAG, "Network monitoring already started");
            return;
        }

        Log.d(TAG, "");
        Log.d(TAG, "╔════════════════════════════════════════╗");
        Log.d(TAG, "║   STARTING NETWORK MONITORING          ║");
        Log.d(TAG, "║   (Modern NetworkCallback Approach)    ║");
        Log.d(TAG, "╚════════════════════════════════════════╝");
        Log.d(TAG, "");

        // Create network request (monitor all networks)
        NetworkRequest networkRequest = new NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build();

        // Create network callback
        networkCallback = new ConnectivityManager.NetworkCallback() {

            /**
             * Called when a network becomes available
             */
            @Override
            public void onAvailable(@NonNull Network network) {
                super.onAvailable(network);

                Log.d(TAG, "");
                Log.d(TAG, "═══ onAvailable() ═══");
                Log.d(TAG, "Network: " + network);
                Log.d(TAG, "A network connection is now available");

                String networkType = getNetworkType(network);
                Log.d(TAG, "Network Type: " + networkType);
                Log.d(TAG, "");

                // Show Toast on main thread
                showToast("📶 ONLINE - Connected via " + networkType);

                Log.d(TAG, "✓ Device is ONLINE");
                Log.d(TAG, "");
            }

            /**
             * Called when network capabilities change
             */
            @Override
            public void onCapabilitiesChanged(@NonNull Network network,
                                              @NonNull NetworkCapabilities capabilities) {
                super.onCapabilitiesChanged(network, capabilities);

                Log.d(TAG, "");
                Log.d(TAG, "═══ onCapabilitiesChanged() ═══");
                Log.d(TAG, "Network: " + network);

                // Check transport types
                boolean isWifi = capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI);
                boolean isCellular = capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR);
                boolean isEthernet = capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET);

                Log.d(TAG, "Capabilities:");
                Log.d(TAG, "  WiFi: " + isWifi);
                Log.d(TAG, "  Cellular: " + isCellular);
                Log.d(TAG, "  Ethernet: " + isEthernet);

                // Check network capabilities
                boolean hasInternet = capabilities.hasCapability(
                        NetworkCapabilities.NET_CAPABILITY_INTERNET);
                boolean isValidated = capabilities.hasCapability(
                        NetworkCapabilities.NET_CAPABILITY_VALIDATED);
                boolean notMetered = capabilities.hasCapability(
                        NetworkCapabilities.NET_CAPABILITY_NOT_METERED);

                Log.d(TAG, "  Internet: " + hasInternet);
                Log.d(TAG, "  Validated: " + isValidated);
                Log.d(TAG, "  Not Metered: " + notMetered);
                Log.d(TAG, "");
            }

            /**
             * Called when a network is lost
             */
            @Override
            public void onLost(@NonNull Network network) {
                super.onLost(network);

                Log.d(TAG, "");
                Log.d(TAG, "═══ onLost() ═══");
                Log.d(TAG, "Network: " + network);
                Log.d(TAG, "Network connection has been lost");
                Log.d(TAG, "");

                // Show Toast on main thread
                showToast("📵 OFFLINE - No Internet Connection");

                Log.d(TAG, "✗ Device is OFFLINE");
                Log.d(TAG, "");
            }

            /**
             * Called when network is unavailable
             */
            @Override
            public void onUnavailable() {
                super.onUnavailable();

                Log.d(TAG, "");
                Log.d(TAG, "═══ onUnavailable() ═══");
                Log.d(TAG, "No network is currently available");
                Log.d(TAG, "");
            }
        };

        // Register the callback
        if (connectivityManager != null) {
            connectivityManager.registerNetworkCallback(networkRequest, networkCallback);
            isRegistered = true;

            Log.d(TAG, "✓ Network callback registered");
            Log.d(TAG, "  Will receive notifications on network changes");
            Log.d(TAG, "");

            // Log current network status
            logCurrentNetworkStatus();
        }
    }

    /**
     * Stop monitoring network changes
     */
    public void stopMonitoring() {
        if (!isRegistered) {
            Log.w(TAG, "Network monitoring not started");
            return;
        }

        Log.d(TAG, "");
        Log.d(TAG, "Stopping network monitoring...");

        if (connectivityManager != null && networkCallback != null) {
            connectivityManager.unregisterNetworkCallback(networkCallback);
            isRegistered = false;

            Log.d(TAG, "✓ Network callback unregistered");
            Log.d(TAG, "");
        }
    }

    /**
     * Get network type string
     */
    private String getNetworkType(Network network) {
        if (connectivityManager == null) return "Unknown";

        NetworkCapabilities capabilities = connectivityManager.getNetworkCapabilities(network);
        if (capabilities == null) return "Unknown";

        if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
            return "WiFi";
        } else if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
            return "Mobile Data";
        } else if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) {
            return "Ethernet";
        }

        return "Other";
    }

    /**
     * Log current network status
     */
    private void logCurrentNetworkStatus() {
        if (connectivityManager == null) return;

        Log.d(TAG, "─── Current Network Status ───");

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Network activeNetwork = connectivityManager.getActiveNetwork();

            if (activeNetwork != null) {
                NetworkCapabilities capabilities =
                        connectivityManager.getNetworkCapabilities(activeNetwork);

                if (capabilities != null) {
                    String type = getNetworkType(activeNetwork);
                    Log.d(TAG, "Status: ONLINE");
                    Log.d(TAG, "Type: " + type);
                } else {
                    Log.d(TAG, "Status: OFFLINE");
                }
            } else {
                Log.d(TAG, "Status: OFFLINE");
            }
        }

        Log.d(TAG, "──────────────────────────────");
        Log.d(TAG, "");
    }

    /**
     * Show toast on main thread
     */
    private void showToast(final String message) {
        // NetworkCallback runs on background thread
        // Must show Toast on main thread
        if (context instanceof MainActivity) {
            ((MainActivity) context).runOnUiThread(() ->
                    Toast.makeText(context, message, Toast.LENGTH_LONG).show()
            );
        }
    }

    /**
     * Check if currently connected
     */
    public boolean isConnected() {
        if (connectivityManager == null) return false;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Network activeNetwork = connectivityManager.getActiveNetwork();
            if (activeNetwork == null) return false;

            NetworkCapabilities capabilities =
                    connectivityManager.getNetworkCapabilities(activeNetwork);

            return capabilities != null &&
                    capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
        }

        return false;
    }
}
