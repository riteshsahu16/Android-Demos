package com.example.t21servicestimestamp;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;

public class MainActivity extends AppCompatActivity {
    /**
     * Main Activity - Controls the background service
     *
     * This activity demonstrates:
     * 1. Starting a background service
     * 2. Reading the file created by the service
     * 3. Stopping the service
     */

    private static final String TAG = "MainActivity";
    private static final String FILENAME = "timestamps.txt";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        Log.d(TAG, "");
        Log.d(TAG, "╔════════════════════════════════════════╗");
        Log.d(TAG, "║   MAIN ACTIVITY STARTED                ║");
        Log.d(TAG, "║   Background Service Demo              ║");
        Log.d(TAG, "╚════════════════════════════════════════╝");
        Log.d(TAG, "");

        // Start the background service
        startBackgroundService();

        // Schedule periodic file reading to demonstrate service is working
        scheduleFileReading();

        // Schedule service stop after 30 seconds (for demo purposes)
        scheduleServiceStop();

        Log.d(TAG, "");
        Log.d(TAG, "Instructions:");
        Log.d(TAG, "  1. Service is now running in background");
        Log.d(TAG, "  2. You can close this app - service continues");
        Log.d(TAG, "  3. Pull down notification shade to see service");
        Log.d(TAG, "  4. Watch logcat for timestamp writes");
        Log.d(TAG, "  5. Service will auto-stop after 30 seconds");
        Log.d(TAG, "");
    }
    /**
     * Start the background service
     */
    private void startBackgroundService() {
        Log.d(TAG, "Starting background service...");

        Intent serviceIntent = new Intent(this, TimestampService.class);
        startService(serviceIntent);

        Log.d(TAG, "✓ Service start request sent");
        Log.d(TAG, "  Service will run even if you close this activity");
        Log.d(TAG, "");
    }

    /**
     * Schedule periodic file reading to show service is working
     */
    private void scheduleFileReading() {
        Handler handler = new Handler(Looper.getMainLooper());

        // Read file every 10 seconds
        Runnable readTask = new Runnable() {
            @Override
            public void run() {
                readTimestampFile();
                handler.postDelayed(this, 10000); // 10 seconds
            }
        };

        // Start after 5 seconds to give service time to write
        handler.postDelayed(readTask, 5000);

        Log.d(TAG, "Scheduled periodic file reading (every 10 seconds)");
    }

    /**
     * Read and display contents of timestamp file
     */
    private void readTimestampFile() {
        Log.d(TAG, "");
        Log.d(TAG, "═══ READING TIMESTAMP FILE ═══");

        try {
            FileInputStream fis = openFileInput(FILENAME);
            BufferedReader reader = new BufferedReader(new InputStreamReader(fis));

            int lineCount = 0;
            String line;
            StringBuilder lastLines = new StringBuilder();

            while ((line = reader.readLine()) != null) {
                lineCount++;
                // Keep only last 5 lines for display
                lastLines.append(line).append("\n");
                if (lineCount > 5) {
                    lastLines.delete(0, lastLines.indexOf("\n") + 1);
                }
            }

            reader.close();
            fis.close();

            Log.d(TAG, "File: " + FILENAME);
            Log.d(TAG, "Total entries: " + lineCount);
            Log.d(TAG, "Last 5 entries:");
            Log.d(TAG, lastLines.toString());

        } catch (Exception e) {
            Log.w(TAG, "File not yet available or empty: " + e.getMessage());
        }
    }

    /**
     * Schedule service stop after 30 seconds (for demo)
     */
    private void scheduleServiceStop() {
        Handler handler = new Handler(Looper.getMainLooper());

        handler.postDelayed(() -> {
            Log.d(TAG, "");
            Log.d(TAG, "30 seconds elapsed - stopping service...");
            stopBackgroundService();
        }, 30000); // 30 seconds

        Log.d(TAG, "Service will auto-stop after 30 seconds");
    }

    /**
     * Stop the background service
     */
    private void stopBackgroundService() {
        Intent serviceIntent = new Intent(this, TimestampService.class);
        boolean stopped = stopService(serviceIntent);

        Log.d(TAG, "Stop service result: " + (stopped ? "Service stopped" : "Service was not running"));

        // Read final file state
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            readTimestampFile();
        }, 1000);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "");
        Log.d(TAG, "MainActivity destroyed");
        Log.d(TAG, "Note: Background service continues running");
        Log.d(TAG, "");
    }

}