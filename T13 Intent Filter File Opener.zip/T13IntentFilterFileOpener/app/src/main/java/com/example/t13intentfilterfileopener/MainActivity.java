package com.example.t13intentfilterfileopener;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.util.Log;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;

public class MainActivity extends AppCompatActivity {
    /**
     * PDF Opener Activity
     *
     * This activity demonstrates how to register as a file opener
     * and handle different types of intents for opening PDF files.
     */
    private static final String TAG = "PDFOpener";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Log.d(TAG, "=== PDF Opener Activity Started ===");

        // Get the intent that started this activity
        Intent intent = getIntent();

        // Log intent details
        logIntentDetails(intent);

        // Handle the intent based on action type
        handleIntent(intent);

        Log.d(TAG, "=== Activity Initialization Complete ===");

    }
    /**
     * Handle new intents if activity is already running
     * This is called when the activity is reused (singleTop or singleTask)
     */
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);

        Log.d(TAG, "=== New Intent Received (Activity Reused) ===");
        setIntent(intent);
        logIntentDetails(intent);
        handleIntent(intent);
    }

    /**
     * Log detailed information about the received intent
     */
    private void logIntentDetails(Intent intent) {
        Log.d(TAG, "--- Intent Details ---");

        // Log action
        String action = intent.getAction();
        Log.d(TAG, "Action: " + (action != null ? action : "null"));

        // Log type (MIME type)
        String type = intent.getType();
        Log.d(TAG, "MIME Type: " + (type != null ? type : "null"));

        // Log data URI
        Uri data = intent.getData();
        Log.d(TAG, "Data URI: " + (data != null ? data.toString() : "null"));

        // Log scheme
        if (data != null) {
            Log.d(TAG, "URI Scheme: " + data.getScheme());
            Log.d(TAG, "URI Path: " + data.getPath());
        }

        // Log categories
        if (intent.getCategories() != null) {
            Log.d(TAG, "Categories: " + intent.getCategories().toString());
        } else {
            Log.d(TAG, "Categories: none");
        }

        // Check for extras
        Bundle extras = intent.getExtras();
        if (extras != null && !extras.isEmpty()) {
            Log.d(TAG, "Extras present: " + extras.size() + " items");
            for (String key : extras.keySet()) {
                Object value = extras.get(key);
                Log.d(TAG, "  Extra: " + key + " = " + value);
            }
        } else {
            Log.d(TAG, "No extras");
        }
    }

    /**
     * Handle different intent actions
     */
    private void handleIntent(Intent intent) {
        String action = intent.getAction();

        if (action == null) {
            Log.w(TAG, "Intent action is null - launched normally");
            return;
        }

        Log.d(TAG, "--- Handling Intent Action ---");

        switch (action) {
            case Intent.ACTION_VIEW:
                Log.d(TAG, "Handling ACTION_VIEW (user wants to view a PDF)");
                handleViewAction(intent);
                break;

            case Intent.ACTION_SEND:
                Log.d(TAG, "Handling ACTION_SEND (PDF shared to this app)");
                handleSendAction(intent);
                break;

            case Intent.ACTION_SEND_MULTIPLE:
                Log.d(TAG, "Handling ACTION_SEND_MULTIPLE (multiple PDFs shared)");
                handleSendMultipleAction(intent);
                break;

            default:
                Log.w(TAG, "Unknown action: " + action);
        }
    }

    /**
     * Handle ACTION_VIEW intent (opening a PDF file)
     */
    private void handleViewAction(Intent intent) {
        Uri uri = intent.getData();

        if (uri == null) {
            Log.e(TAG, "No URI provided with VIEW action");
            return;
        }

        Log.d(TAG, "=== Processing PDF File ===");

        // Get file information
        getPdfFileInfo(uri);

        // Verify we can read the file
        verifyFileAccess(uri);

        // In a real app, you would now:
        // 1. Use a PDF library (like PDFBox, Android-PdfViewer, etc.)
        // 2. Render the PDF content
        // 3. Display it to the user

        Log.d(TAG, "PDF file ready to be displayed");
        Log.d(TAG, "In production: Use PDF rendering library here");
    }

    /**
     * Handle ACTION_SEND intent (PDF shared from another app)
     */
    private void handleSendAction(Intent intent) {
        Uri uri = intent.getParcelableExtra(Intent.EXTRA_STREAM);

        if (uri == null) {
            Log.e(TAG, "No URI in EXTRA_STREAM for SEND action");
            return;
        }

        Log.d(TAG, "=== Processing Shared PDF ===");
        Log.d(TAG, "Shared URI: " + uri);

        // Get file information
        getPdfFileInfo(uri);

        // Check for additional text
        String sharedText = intent.getStringExtra(Intent.EXTRA_TEXT);
        if (sharedText != null) {
            Log.d(TAG, "Shared text: " + sharedText);
        }
    }

    /**
     * Handle ACTION_SEND_MULTIPLE intent (multiple PDFs shared)
     */
    private void handleSendMultipleAction(Intent intent) {
        java.util.ArrayList<Uri> uris =
                intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM);

        if (uris == null || uris.isEmpty()) {
            Log.e(TAG, "No URIs in EXTRA_STREAM for SEND_MULTIPLE action");
            return;
        }

        Log.d(TAG, "=== Processing Multiple Shared PDFs ===");
        Log.d(TAG, "Number of PDFs: " + uris.size());

        for (int i = 0; i < uris.size(); i++) {
            Log.d(TAG, "\n--- PDF " + (i + 1) + " of " + uris.size() + " ---");
            getPdfFileInfo(uris.get(i));
        }
    }

    /**
     * Get detailed information about the PDF file
     */
    private void getPdfFileInfo(Uri uri) {
        Log.d(TAG, "--- File Information ---");
        Log.d(TAG, "URI: " + uri.toString());
        Log.d(TAG, "Scheme: " + uri.getScheme());

        // Handle content:// URIs (recommended modern approach)
        if ("content".equals(uri.getScheme())) {
            getContentUriInfo(uri);
        }
        // Handle file:// URIs (legacy, deprecated in Android 7.0+)
        else if ("file".equals(uri.getScheme())) {
            getFileUriInfo(uri);
        }
        else {
            Log.w(TAG, "Unknown URI scheme: " + uri.getScheme());
        }
    }

    /**
     * Get information from content:// URI (modern approach)
     */
    private void getContentUriInfo(Uri uri) {
        Log.d(TAG, "Processing content:// URI");

        // Query the content provider for file metadata
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(
                    uri,
                    null,  // null = get all columns
                    null,
                    null,
                    null
            );

            if (cursor != null && cursor.moveToFirst()) {
                // Get display name
                int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (nameIndex >= 0) {
                    String displayName = cursor.getString(nameIndex);
                    Log.d(TAG, "File Name: " + displayName);
                }

                // Get file size
                int sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE);
                if (sizeIndex >= 0) {
                    long size = cursor.getLong(sizeIndex);
                    Log.d(TAG, "File Size: " + formatFileSize(size));
                }
            } else {
                Log.w(TAG, "Could not query content provider for metadata");
            }
        } catch (Exception e) {
            Log.e(TAG, "Error querying content provider: " + e.getMessage());
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    /**
     * Get information from file:// URI (legacy approach)
     */
    private void getFileUriInfo(Uri uri) {
        Log.d(TAG, "Processing file:// URI (deprecated)");
        Log.w(TAG, "Note: file:// URIs are deprecated since Android 7.0");
        Log.w(TAG, "Recommended: Use FileProvider and content:// URIs");

        try {
            File file = new File(uri.getPath());
            Log.d(TAG, "File Name: " + file.getName());
            Log.d(TAG, "File Size: " + formatFileSize(file.length()));
            Log.d(TAG, "File Exists: " + file.exists());
            Log.d(TAG, "Can Read: " + file.canRead());
            Log.d(TAG, "Absolute Path: " + file.getAbsolutePath());
        } catch (Exception e) {
            Log.e(TAG, "Error reading file:// URI: " + e.getMessage());
        }
    }

    /**
     * Verify that we can actually access the file
     */
    private void verifyFileAccess(Uri uri) {
        Log.d(TAG, "--- Verifying File Access ---");

        try {
            InputStream inputStream = getContentResolver().openInputStream(uri);

            if (inputStream != null) {
                // Check how many bytes we can read
                int available = inputStream.available();
                Log.d(TAG, "✓ File is accessible");
                Log.d(TAG, "Available bytes: " + available);
                inputStream.close();
            } else {
                Log.e(TAG, "✗ Input stream is null");
            }

        } catch (FileNotFoundException e) {
            Log.e(TAG, "✗ File not found: " + e.getMessage());
        } catch (Exception e) {
            Log.e(TAG, "✗ Error accessing file: " + e.getMessage());
        }
    }

    /**
     * Format file size for readable logging
     */
    private String formatFileSize(long bytes) {
        if (bytes < 1024) {
            return bytes + " B";
        } else if (bytes < 1024 * 1024) {
            return String.format("%.2f KB", bytes / 1024.0);
        } else if (bytes < 1024 * 1024 * 1024) {
            return String.format("%.2f MB", bytes / (1024.0 * 1024.0));
        } else {
            return String.format("%.2f GB", bytes / (1024.0 * 1024.0 * 1024.0));
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "=== PDF Opener Activity Destroyed ===");
    }
}