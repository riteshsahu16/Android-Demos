package com.example.t15metadata;

import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class DetailsActivity extends AppCompatActivity {
    /**
     * Secondary activity demonstrating different metadata configuration
     */
    private static final String TAG = "MetadataDemo-Details";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_details);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        Log.d(TAG, "Details Activity Started");

        // Read this activity's metadata
        readActivityMetadata();
    }
    private void readActivityMetadata() {
        try {
            PackageManager pm = getPackageManager();
            ActivityInfo info = pm.getActivityInfo(
                    getComponentName(),
                    PackageManager.GET_META_DATA
            );

            if (info.metaData != null) {
                String screenType = info.metaData.getString(
                        "activity.config.screen_type"
                );
                boolean showToolbar = info.metaData.getBoolean(
                        "activity.config.show_toolbar"
                );
                boolean allowScreenshots = info.metaData.getBoolean(
                        "activity.config.allow_screenshots",
                        true
                );

                Log.d(TAG, "Details Activity Metadata:");
                Log.d(TAG, "  Screen Type: " + screenType);
                Log.d(TAG, "  Show Toolbar: " + showToolbar);
                Log.d(TAG, "  Allow Screenshots: " + allowScreenshots);
            }

        } catch (Exception e) {
            Log.e(TAG, "Error reading metadata: " + e.getMessage());
        }
    }
}