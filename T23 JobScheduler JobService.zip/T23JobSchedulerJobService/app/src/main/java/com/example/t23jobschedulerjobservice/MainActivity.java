package com.example.t23jobschedulerjobservice;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.util.Log;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.List;

/**
 * Main Activity - Demonstrates scheduling jobs with JobScheduler
 *
 * Shows different types of jobs:
 * 1. Simple job (runs immediately)
 * 2. Job with network constraint
 * 3. Job with charging constraint
 * 4. Job with multiple constraints
 * 5. Periodic job (API 24+)
 * 6. Job with deadline
 */
public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";

    // Job IDs
    private static final int JOB_ID_SIMPLE = 1;
    private static final int JOB_ID_NETWORK = 2;
    private static final int JOB_ID_CHARGING = 3;
    private static final int JOB_ID_MULTI_CONSTRAINT = 4;
    private static final int JOB_ID_PERIODIC = 100;
    private static final int JOB_ID_DEADLINE = 5;

    private JobScheduler jobScheduler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        Log.d(TAG, "");
        Log.d(TAG, "╔════════════════════════════════════════╗");
        Log.d(TAG, "║   JOBSCHEDULER DEMO STARTED            ║");
        Log.d(TAG, "╚════════════════════════════════════════╝");
        Log.d(TAG, "");

        // Get JobScheduler system service
        jobScheduler = (JobScheduler) getSystemService(Context.JOB_SCHEDULER_SERVICE);

        if (jobScheduler == null) {
            Log.e(TAG, "✗ JobScheduler not available on this device");
            return;
        }

        Log.d(TAG, "✓ JobScheduler service obtained");
        Log.d(TAG, "");

        // Check API level
        Log.d(TAG, "Android Version: " + Build.VERSION.SDK_INT + " (API " + Build.VERSION.SDK_INT + ")");
        Log.d(TAG, "Minimum required: API 21 (Lollipop)");
        Log.d(TAG, "");

        // Schedule various types of jobs
        scheduleAllJobs();

        // Display scheduled jobs
        displayScheduledJobs();
    }
    /**
     * Schedule all demo jobs
     */
    private void scheduleAllJobs() {
        Log.d(TAG, "═══ SCHEDULING JOBS ═══");
        Log.d(TAG, "");

        // 1. Simple job
        scheduleSimpleJob();

        // 2. Network constraint job
        scheduleNetworkJob();

        // 3. Charging constraint job
        scheduleChargingJob();

        // 4. Multi-constraint job
        scheduleMultiConstraintJob();

        // 5. Periodic job (API 24+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            schedulePeriodicJob();
        }

        // 6. Job with deadline
        scheduleDeadlineJob();

        Log.d(TAG, "");
        Log.d(TAG, "All jobs scheduled successfully!");
        Log.d(TAG, "");
    }

    /**
     * 1. Simple Job - Runs as soon as possible
     */
    private void scheduleSimpleJob() {
        Log.d(TAG, "┌─────────────────────────────────────┐");
        Log.d(TAG, "│   1. SIMPLE JOB                     │");
        Log.d(TAG, "└─────────────────────────────────────┘");
        Log.d(TAG, "");

        ComponentName serviceName = new ComponentName(this, MyJobService.class);

        // Create extras (custom data)
        PersistableBundle extras = new PersistableBundle();
        extras.putString("job_type", "LOGGING");
        extras.putString("description", "Simple job with no constraints");

        // Build JobInfo
        JobInfo jobInfo = new JobInfo.Builder(JOB_ID_SIMPLE, serviceName)
                .setExtras(extras)
                // No constraints - runs immediately
                .build();

        int result = jobScheduler.schedule(jobInfo);

        Log.d(TAG, "Job ID: " + JOB_ID_SIMPLE);
        Log.d(TAG, "Type: LOGGING");
        Log.d(TAG, "Constraints: None");
        Log.d(TAG, "Execution: Immediate");
        Log.d(TAG, "Result: " + (result == JobScheduler.RESULT_SUCCESS ? "SUCCESS" : "FAILURE"));
        Log.d(TAG, "");
    }

    /**
     * 2. Network Constraint Job - Runs only when network available
     */
    private void scheduleNetworkJob() {
        Log.d(TAG, "┌─────────────────────────────────────┐");
        Log.d(TAG, "│   2. NETWORK CONSTRAINT JOB         │");
        Log.d(TAG, "└─────────────────────────────────────┘");
        Log.d(TAG, "");

        ComponentName serviceName = new ComponentName(this, MyJobService.class);

        PersistableBundle extras = new PersistableBundle();
        extras.putString("job_type", "NETWORK");
        extras.putString("description", "Requires network connection");

        // Build JobInfo with network constraint
        JobInfo jobInfo = new JobInfo.Builder(JOB_ID_NETWORK, serviceName)
                .setExtras(extras)
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)  // Any network (WiFi or cellular)
                .build();

        int result = jobScheduler.schedule(jobInfo);

        Log.d(TAG, "Job ID: " + JOB_ID_NETWORK);
        Log.d(TAG, "Type: NETWORK");
        Log.d(TAG, "Constraints:");
        Log.d(TAG, "  ✓ Network: NETWORK_TYPE_ANY (WiFi or cellular)");
        Log.d(TAG, "Execution: When network available");
        Log.d(TAG, "Result: " + (result == JobScheduler.RESULT_SUCCESS ? "SUCCESS" : "FAILURE"));
        Log.d(TAG, "");
        Log.d(TAG, "Options: NETWORK_TYPE_NONE | NETWORK_TYPE_ANY |");
        Log.d(TAG, "         NETWORK_TYPE_UNMETERED (WiFi only) |");
        Log.d(TAG, "         NETWORK_TYPE_NOT_ROAMING");
        Log.d(TAG, "");
    }

    /**
     * 3. Charging Constraint Job - Runs only when device is charging
     */
    private void scheduleChargingJob() {
        Log.d(TAG, "┌─────────────────────────────────────┐");
        Log.d(TAG, "│   3. CHARGING CONSTRAINT JOB        │");
        Log.d(TAG, "└─────────────────────────────────────┘");
        Log.d(TAG, "");

        ComponentName serviceName = new ComponentName(this, MyJobService.class);

        PersistableBundle extras = new PersistableBundle();
        extras.putString("job_type", "DATA_SYNC");
        extras.putString("description", "Runs when device is charging");

        // Build JobInfo with charging constraint
        JobInfo jobInfo = new JobInfo.Builder(JOB_ID_CHARGING, serviceName)
                .setExtras(extras)
                .setRequiresCharging(true)  // Only run when plugged in
                .build();

        int result = jobScheduler.schedule(jobInfo);

        Log.d(TAG, "Job ID: " + JOB_ID_CHARGING);
        Log.d(TAG, "Type: DATA_SYNC");
        Log.d(TAG, "Constraints:");
        Log.d(TAG, "  ✓ Charging: true (device must be plugged in)");
        Log.d(TAG, "Execution: When device is charging");
        Log.d(TAG, "Result: " + (result == JobScheduler.RESULT_SUCCESS ? "SUCCESS" : "FAILURE"));
        Log.d(TAG, "");
        Log.d(TAG, "💡 Test on emulator: Settings → Battery → AC Charger");
        Log.d(TAG, "");
    }

    /**
     * 4. Multi-Constraint Job - Multiple constraints must be met
     */
    private void scheduleMultiConstraintJob() {
        Log.d(TAG, "┌─────────────────────────────────────┐");
        Log.d(TAG, "│   4. MULTI-CONSTRAINT JOB           │");
        Log.d(TAG, "└─────────────────────────────────────┘");
        Log.d(TAG, "");

        ComponentName serviceName = new ComponentName(this, MyJobService.class);

        PersistableBundle extras = new PersistableBundle();
        extras.putString("job_type", "DATA_SYNC");
        extras.putString("description", "Large sync - optimal conditions");

        // Build JobInfo with multiple constraints
        JobInfo.Builder builder = new JobInfo.Builder(JOB_ID_MULTI_CONSTRAINT, serviceName)
                .setExtras(extras)
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_UNMETERED)  // WiFi only
                .setRequiresCharging(true)                                // Must be charging
                .setRequiresBatteryNotLow(true)                          // Battery not low
                .setRequiresStorageNotLow(true);                         // Storage not low

        // Add device idle constraint if API 23+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            builder.setRequiresDeviceIdle(true);  // Device must be idle
        }

        JobInfo jobInfo = builder.build();
        int result = jobScheduler.schedule(jobInfo);

        Log.d(TAG, "Job ID: " + JOB_ID_MULTI_CONSTRAINT);
        Log.d(TAG, "Type: DATA_SYNC");
        Log.d(TAG, "Constraints (ALL must be met):");
        Log.d(TAG, "  ✓ Network: UNMETERED (WiFi only)");
        Log.d(TAG, "  ✓ Charging: true");
        Log.d(TAG, "  ✓ Battery: Not low");
        Log.d(TAG, "  ✓ Storage: Not low");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Log.d(TAG, "  ✓ Device: Idle (API 23+)");
        }
        Log.d(TAG, "Execution: When ALL constraints satisfied");
        Log.d(TAG, "Result: " + (result == JobScheduler.RESULT_SUCCESS ? "SUCCESS" : "FAILURE"));
        Log.d(TAG, "");
        Log.d(TAG, "⚠ This job may take a while to execute");
        Log.d(TAG, "  due to strict constraints");
        Log.d(TAG, "");
    }

    /**
     * 5. Periodic Job - Runs at regular intervals (API 24+)
     */
    private void schedulePeriodicJob() {
        Log.d(TAG, "┌─────────────────────────────────────┐");
        Log.d(TAG, "│   5. PERIODIC JOB (API 24+)         │");
        Log.d(TAG, "└─────────────────────────────────────┘");
        Log.d(TAG, "");

        ComponentName serviceName = new ComponentName(this, MyJobService.class);

        PersistableBundle extras = new PersistableBundle();
        extras.putString("job_type", "LOGGING");
        extras.putString("description", "Periodic sync job");

        // Build periodic job (API 24+)
        // Minimum interval: 15 minutes
        JobInfo jobInfo = new JobInfo.Builder(JOB_ID_PERIODIC, serviceName)
                .setExtras(extras)
                .setPeriodic(15 * 60 * 1000)  // 15 minutes in milliseconds
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .build();

        int result = jobScheduler.schedule(jobInfo);

        Log.d(TAG, "Job ID: " + JOB_ID_PERIODIC);
        Log.d(TAG, "Type: LOGGING (Periodic)");
        Log.d(TAG, "Interval: 15 minutes (minimum allowed)");
        Log.d(TAG, "Constraints:");
        Log.d(TAG, "  ✓ Network: Any");
        Log.d(TAG, "Repeats: Until cancelled");
        Log.d(TAG, "Result: " + (result == JobScheduler.RESULT_SUCCESS ? "SUCCESS" : "FAILURE"));
        Log.d(TAG, "");
        Log.d(TAG, "⚠ First execution in ~15 minutes");
        Log.d(TAG, "  Subsequent runs every 15 minutes");
        Log.d(TAG, "");
    }

    /**
     * 6. Job with Deadline - Must run within specified time
     */
    private void scheduleDeadlineJob() {
        Log.d(TAG, "┌─────────────────────────────────────┐");
        Log.d(TAG, "│   6. JOB WITH DEADLINE              │");
        Log.d(TAG, "└─────────────────────────────────────┘");
        Log.d(TAG, "");

        ComponentName serviceName = new ComponentName(this, MyJobService.class);

        PersistableBundle extras = new PersistableBundle();
        extras.putString("job_type", "LOGGING");
        extras.putString("description", "Job with override deadline");

        // Build job with deadline
        JobInfo jobInfo = new JobInfo.Builder(JOB_ID_DEADLINE, serviceName)
                .setExtras(extras)
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setOverrideDeadline(10 * 1000)  // Maximum wait: 10 seconds
                .build();

        int result = jobScheduler.schedule(jobInfo);

        Log.d(TAG, "Job ID: " + JOB_ID_DEADLINE);
        Log.d(TAG, "Type: LOGGING");
        Log.d(TAG, "Constraints:");
        Log.d(TAG, "  ✓ Network: Any");
        Log.d(TAG, "  ✓ Deadline: 10 seconds (override)");
        Log.d(TAG, "Execution: Within 10 seconds regardless of constraints");
        Log.d(TAG, "Result: " + (result == JobScheduler.RESULT_SUCCESS ? "SUCCESS" : "FAILURE"));
        Log.d(TAG, "");
        Log.d(TAG, "Note: If network unavailable, job still runs after 10s");
        Log.d(TAG, "      Deadline overrides constraints");
        Log.d(TAG, "");
    }

    /**
     * Display all currently scheduled jobs
     */
    private void displayScheduledJobs() {
        Log.d(TAG, "═══ SCHEDULED JOBS ═══");
        Log.d(TAG, "");

        List<JobInfo> allPendingJobs = jobScheduler.getAllPendingJobs();

        Log.d(TAG, "Total scheduled jobs: " + allPendingJobs.size());
        Log.d(TAG, "");

        if (!allPendingJobs.isEmpty()) {
            for (JobInfo job : allPendingJobs) {
                Log.d(TAG, "Job ID " + job.getId() + ":");
                Log.d(TAG, "  Service: " + job.getService().getClassName());
                Log.d(TAG, "  Network Type: " + job.getNetworkType());
                Log.d(TAG, "  Requires Charging: " + job.isRequireCharging());
                Log.d(TAG, "  Requires Device Idle: " + job.isRequireDeviceIdle());

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    if (job.isPeriodic()) {
                        Log.d(TAG, "  Type: PERIODIC");
                        Log.d(TAG, "  Interval: " + (job.getIntervalMillis() / 1000) + " seconds");
                    }
                }

                Log.d(TAG, "");
            }
        }

        Log.d(TAG, "Watch logcat for job executions");
        Log.d(TAG, "Filter by: MyJobService");
        Log.d(TAG, "");
    }

    /**
     * Cancel all jobs when activity is destroyed
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();

        Log.d(TAG, "");
        Log.d(TAG, "MainActivity destroyed");

        // Optional: Cancel all jobs
        // Uncomment to cancel when activity closes
        /*
        Log.d(TAG, "Cancelling all scheduled jobs...");
        jobScheduler.cancelAll();
        Log.d(TAG, "✓ All jobs cancelled");
        */

        Log.d(TAG, "Note: Scheduled jobs continue even after activity closes");
        Log.d(TAG, "");
    }
}